// Background: holds the session token, talks to the QuestCampus backend (auth +
// data bundle), and fetches document bytes cross-origin (bypassing page CORS) so
// the content script can attach them. Popup + content message us here.

// Chrome MV3 service worker. `chrome.*` supports promises in MV3; a tiny shim keeps
// the shared handler code identical to the Firefox build.
const browser = globalThis.browser ?? chrome;
const BASE = "https://api.questcampus.space";

// Toolbar button opens the docked side panel (Chrome sidePanel API).
chrome.runtime.onInstalled.addListener(() => {
  try { chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }); } catch (e) { /* older Chrome */ }
});

// chrome.runtime message payloads must be JSON-ifiable — ArrayBuffer doesn't
// survive that boundary, so document bytes cross as base64 instead.
function arrayBufferToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  const chunk = 0x8000;
  for (let i = 0; i < bytes.length; i += chunk) {
    binary += String.fromCharCode.apply(null, bytes.subarray(i, i + chunk));
  }
  return btoa(binary);
}

async function getToken() {
  const s = await browser.storage.local.get("token");
  return s.token || null;
}

async function handle(msg) {
  switch (msg && msg.type) {
    case "STATE": {
      return { token: await getToken() };
    }
    case "SIGNIN": {
      try {
        const r = await fetch(BASE + "/api/auth/sign-in", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: msg.email, password: msg.password }),
        });
        const j = await r.json().catch(() => ({}));
        if (!r.ok || !j.token) return { ok: false, error: j.error || "Invalid email or password." };
        await browser.storage.local.set({ token: j.token, email: (j.user && j.user.email) || msg.email });
        return { ok: true };
      } catch (e) {
        return { ok: false, error: "Network error — check your connection." };
      }
    }
    case "BUNDLE": {
      const token = await getToken();
      if (!token) return { ok: false, error: "Not signed in." };
      try {
        const r = await fetch(BASE + "/api/ext/bundle", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token }),
        });
        if (r.status === 401) return { ok: false, error: "Session expired." };
        if (!r.ok) return { ok: false, error: "Couldn't load your profile." };
        return { ok: true, data: await r.json() };
      } catch (e) {
        return { ok: false, error: "Network error." };
      }
    }
    case "GOOGLE": {
      // Reuse the web OAuth flow end-to-end, but use the extension's own redirect
      // URL as returnUrl so launchWebAuthFlow catches the backend's 302 back.
      // Google's registered redirect_uri stays the backend (/redirect) — unchanged.
      try {
        const redirectUri = browser.identity.getRedirectURL();
        const s = await fetch(BASE + "/api/auth/google/start", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ returnUrl: redirectUri }),
        });
        const sj = await s.json().catch(() => ({}));
        if (!s.ok || !sj.authorizationUrl)
          return { ok: false, error: sj.error || "Google sign-in is unavailable." };

        const finalUrl = await browser.identity.launchWebAuthFlow({
          url: sj.authorizationUrl,
          interactive: true,
        });
        const u = new URL(finalUrl);
        const code = u.searchParams.get("code");
        const state = u.searchParams.get("state");
        const oauthErr = u.searchParams.get("error");
        if (oauthErr || !code || !state)
          return { ok: false, error: oauthErr || "Google sign-in was cancelled." };

        const c = await fetch(BASE + "/api/auth/google/callback", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ code, state }),
        });
        const cj = await c.json().catch(() => ({}));
        if (!c.ok || !cj.token)
          return { ok: false, error: cj.error || "Couldn't complete Google sign-in." };

        await browser.storage.local.set({ token: cj.token, email: (cj.user && cj.user.email) || "" });
        return { ok: true };
      } catch (e) {
        const m = String((e && e.message) || e);
        if (/cancel|closed|denied|user/i.test(m))
          return { ok: false, error: "Google sign-in was cancelled." };
        return { ok: false, error: "Google sign-in failed — try email instead." };
      }
    }
    case "SIGNOUT": {
      await browser.storage.local.remove(["token", "email"]);
      return { ok: true };
    }
    case "PLAN": {
      const token = await getToken();
      if (!token) return { ok: false, error: "Not signed in." };
      try {
        const r = await fetch(BASE + "/api/ext/plan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, fields: msg.fields || [], title: msg.title || "", addButtons: msg.addButtons || [] }),
        });
        if (r.status === 401) return { ok: false, error: "Session expired." };
        if (!r.ok) return { ok: false, error: "AI mapping failed." };
        const j = await r.json().catch(() => ({}));
        return { ok: true, decisions: j.decisions || [], addRows: j.addRows || [] };
      } catch (e) {
        return { ok: false, error: "Network error." };
      }
    }
    case "SCAN": {
      const token = await getToken();
      if (!token) return { ok: false, error: "Not signed in." };
      try {
        const r = await fetch(BASE + "/api/ext/scan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, host: msg.host || "", fields: msg.fields || [] }),
        });
        if (!r.ok) return { ok: false, error: "Scan failed." };
        return { ok: true, ...(await r.json().catch(() => ({}))) };
      } catch (e) {
        return { ok: false, error: "Network error." };
      }
    }
    case "DEEP_SCAN": {
      const token = await getToken();
      if (!token) return { ok: false, error: "Not signed in." };
      try {
        const r = await fetch(BASE + "/api/ext/deepscan", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, host: msg.host || "", section: msg.section || "", fields: msg.fields || [] }),
        });
        if (!r.ok) return { ok: false, error: "Deep scan failed." };
        return { ok: true, ...(await r.json().catch(() => ({}))) };
      } catch (e) {
        return { ok: false, error: "Network error." };
      }
    }
    case "DRIFT": {
      const token = await getToken();
      if (!token) return { ok: false };
      try {
        await fetch(BASE + "/api/ext/drift", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, host: msg.host || "", section: msg.section || "", fields: msg.fields || [] }),
        });
        return { ok: true };
      } catch (e) {
        return { ok: false };
      }
    }
    case "FILLREPORT": {
      const token = await getToken();
      if (!token) return { ok: false };
      try {
        await fetch(BASE + "/api/ext/fillreport", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ token, host: msg.host || "", title: msg.title || "", items: msg.items || [], debug: msg.debug || "" }),
        });
        return { ok: true };
      } catch (e) {
        return { ok: false };
      }
    }
    case "APPLY_STATUS": {
      // Mirror a per-portal apply job's state to Convex applyJobs (Bearer path)
      // so the web dashboard + a reopened side panel recover progress. Additive:
      // the side-panel orchestrator posts this on every job state change.
      const token = await getToken();
      if (!token) return { ok: false, error: "Not signed in." };
      try {
        await fetch(BASE + "/api/ext/applystatus", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({
            token,
            jobId: msg.jobId,
            system: msg.system || "",
            externalId: msg.externalId || "",
            state: msg.state || "",
            progress: msg.progress || null,
          }),
        });
        return { ok: true };
      } catch (e) {
        return { ok: false };
      }
    }
    case "FETCH_DOC": {
      try {
        const r = await fetch(msg.url);
        if (!r.ok) return { ok: false };
        // chrome.runtime messages must be JSON-ifiable — an ArrayBuffer serializes
        // to "{}" across the service-worker boundary, so base64-encode it here.
        const bytes = arrayBufferToBase64(await r.arrayBuffer());
        return { ok: true, bytes, mime: r.headers.get("Content-Type") || "application/octet-stream" };
      } catch (e) {
        return { ok: false };
      }
    }
    case "GET_MAP": {
      // The authoritative Common App field map (produced by Claude Cowork), bundled
      // with the extension. The side panel asks for it; the content script fills by it.
      try {
        const r = await fetch(chrome.runtime.getURL("commonAppMap.json"));
        if (!r.ok) return { ok: false, error: "Map not found." };
        return { ok: true, map: await r.json() };
      } catch (e) {
        return { ok: false, error: "Couldn't load the field map." };
      }
    }
    default:
      return undefined;
  }
}

// MV3 receivers must use sendResponse + return true for async (promise-return is
// Firefox-only). The SENDER side (chrome.runtime/tabs.sendMessage) returns promises.
browser.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  handle(msg).then(sendResponse).catch((e) => sendResponse({ ok: false, error: String(e) }));
  return true;
});
