// DOM adapter — the seam between a live page and the pure PortalSpec matcher.
// Given a root Document/Element it produces `ElementMeta` records
// ({ label, aria, name, id, el }) for the fillable widgets, so
// PortalSpec.scoreCandidate / pickBest can match a Field to a real element.
//
// This DOES NOT fill anything — it only reads. The live fill path stays in
// content.js. This module is additive and consumed by the Phase 4 fill driver.
//
// UMD-ish: attaches `globalThis.QCDomAdapter` for classic content-script /
// side-panel use, and sets module.exports under Node (for any future test).
// Label derivation mirrors content.js's `labelFor` approach conceptually
// (for/[for], wrapping <label>, aria-label, aria-labelledby, Common App
// .control__label, nearest container label, then placeholder/name).
(function (root) {
  "use strict";

  function textOf(el) {
    // Label text minus any nested control text (a wrapping <label> around a
    // radio yields just the option words).
    const clone = el.cloneNode(true);
    clone.querySelectorAll("input,select,textarea,button").forEach((n) => n.remove());
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
  }

  // Common App wraps each field in <ca-control-wrapper> whose question text is a
  // SIBLING (.control__label), not an ancestor — the generic heuristics miss it.
  function caWrapLabel(el) {
    const w = el.closest && el.closest("ca-control-wrapper, [class*=control-wrapper]");
    if (!w) return "";
    const l = w.querySelector(".control__label, ca-control-wrapper-label");
    return l ? (l.textContent || "").replace(/\s+/g, " ").trim() : "";
  }

  function ariaLabel(el) {
    const al = el.getAttribute && el.getAttribute("aria-label");
    if (al && al.trim()) return al.trim();
    const lb = el.getAttribute && el.getAttribute("aria-labelledby");
    if (lb) {
      const doc = el.ownerDocument || document;
      const t = lb
        .split(/\s+/)
        .map((i) => { const n = doc.getElementById(i); return n && n.textContent; })
        .filter(Boolean)
        .join(" ")
        .trim();
      if (t) return t;
    }
    return "";
  }

  function labelText(el) {
    const doc = el.ownerDocument || document;
    if (el.id) {
      const l = doc.querySelector(`label[for="${cssEscape(el.id)}"]`);
      if (l && l.textContent.trim()) return l.textContent.trim();
    }
    const wrap = el.closest && el.closest("label");
    if (wrap) { const t = textOf(wrap); if (t) return t; }
    const aria = ariaLabel(el);
    if (aria) return aria;
    const cw = caWrapLabel(el);
    if (cw) return cw;
    const cont = el.closest && el.closest("[class*=field],[class*=question],[class*=form-group],[class*=form-item],fieldset,div");
    const q = cont && cont.querySelector("label,legend,[class*=label]");
    if (q && q !== el && q.textContent.trim()) return q.textContent.trim();
    return (el.getAttribute("placeholder") || el.getAttribute("name") || "").trim();
  }

  function cssEscape(s) {
    if (typeof CSS !== "undefined" && CSS.escape) return CSS.escape(s);
    return String(s).replace(/["\\\]\[#.:>+~*^$|=()]/g, "\\$&");
  }

  // Produce the ElementMeta PortalSpec.scoreCandidate expects, plus `el` so the
  // caller can act on the matched node. Shape: { label, aria, name, id, el }.
  function elementMeta(el) {
    return {
      label: labelText(el),
      aria: ariaLabel(el),
      name: (el.getAttribute && el.getAttribute("name")) || "",
      id: el.id || "",
      el,
    };
  }

  // Candidate fillable elements under `root` (default: document). Skips password
  // fields, hidden inputs, submit/button types — same safety posture as the live
  // fill path. Returns an array of ElementMeta.
  function collectCandidates(root) {
    const scope = root || (typeof document !== "undefined" ? document : null);
    if (!scope || !scope.querySelectorAll) return [];
    const out = [];
    const els = scope.querySelectorAll("input, select, textarea, [role=combobox], [contenteditable=true]");
    for (const el of els) {
      const type = (el.getAttribute && (el.getAttribute("type") || "")).toLowerCase();
      if (el.tagName === "INPUT" && (type === "password" || type === "hidden" || type === "submit" || type === "button" || type === "reset")) continue;
      out.push(elementMeta(el));
    }
    return out;
  }

  const api = { elementMeta, collectCandidates, labelText, ariaLabel };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.QCDomAdapter = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
