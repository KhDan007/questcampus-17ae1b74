// Concurrent multi-portal fill orchestrator (side-panel plane).
//
// Lives in the side-panel PAGE (a real page that persists while open) — NOT the
// MV3 service worker, whose ephemeral lifetime would drop orchestration state.
// It runs a bounded job queue: opens up to N background tabs, tells each tab's
// content script to fill by its portal field map, tracks per-tab progress,
// promotes a tab to `needs_human` when it hits a login/CAPTCHA/custom-upload
// gate, frees the slot, and starts the next queued job. It NEVER auto-submits —
// content.js walks to Review and stops; the user submits each portal themselves.
//
// PortalJob = { id, system, externalId, entryUrl, tabId?, state, progress? }
//   state ∈ queued | opening | filling | needs_human | ready_for_review | done | error
//   progress = { filled, unmatched, uploaded, blocked? }
//
// The PURE bits (nextToStart, summarize, activeCount, applyProgress) are exported
// and unit-tested in orchestrator.test.mjs. The tab/DOM control is injected
// (createTab/fillTab/reportStatus) so it is testable and the class stays thin.
//
// UMD-ish: `globalThis.QCOrchestrator` for the classic-script side panel;
// module.exports for the Node test.
(function (root) {
  "use strict";

  const DEFAULT_CAP = 3;

  // States that occupy a concurrency slot (a tab actively being driven). A
  // `needs_human` tab is waiting on the user, so it FREES the slot — other tabs
  // keep filling while it waits (per the design's human-gate behavior).
  const ACTIVE_STATES = new Set(["opening", "filling"]);
  // Terminal-ish states that never need a slot again.
  const SETTLED_STATES = new Set(["needs_human", "ready_for_review", "done", "error"]);

  // ── pure: how many jobs currently hold a slot ────────────────────────────────
  function activeCount(jobs) {
    let n = 0;
    for (const j of jobs) if (ACTIVE_STATES.has(j.state)) n++;
    return n;
  }

  // ── pure: which queued jobs to start next, given the cap + running count ──────
  // Returns the ordered slice of `queued` jobs that fit the free slots
  // (cap - running). `running` defaults to activeCount(jobs) so callers can pass
  // just (jobs, cap).
  function nextToStart(jobs, cap, running) {
    const c = typeof cap === "number" && cap > 0 ? cap : DEFAULT_CAP;
    const run = typeof running === "number" ? running : activeCount(jobs);
    const free = Math.max(0, c - run);
    if (free === 0) return [];
    const queued = jobs.filter((j) => j.state === "queued");
    return queued.slice(0, free);
  }

  // ── pure: fold a per-tab progress report into a job (returns a NEW job) ───────
  // blocked report → needs_human; otherwise the caller decides ready/done.
  function applyProgress(job, progress) {
    const p = progress || {};
    const merged = {
      filled: num(p.filled),
      unmatched: num(p.unmatched),
      uploaded: num(p.uploaded),
    };
    if (p.blocked) merged.blocked = String(p.blocked);
    const next = Object.assign({}, job, { progress: merged });
    if (p.blocked) next.state = "needs_human";
    return next;
  }

  function num(x) { return typeof x === "number" && isFinite(x) ? x : 0; }

  // ── pure: the confirm-all aggregate ──────────────────────────────────────────
  function summarize(jobs) {
    const byState = { queued: 0, opening: 0, filling: 0, needs_human: 0, ready_for_review: 0, done: 0, error: 0 };
    let filled = 0, unmatched = 0, uploaded = 0;
    const blocked = [];
    for (const j of jobs) {
      if (byState[j.state] === undefined) byState[j.state] = 0;
      byState[j.state]++;
      const p = j.progress || {};
      filled += num(p.filled);
      unmatched += num(p.unmatched);
      uploaded += num(p.uploaded);
      if (j.state === "needs_human") blocked.push({ id: j.id, reason: (p.blocked ? String(p.blocked) : "needs_human") });
    }
    // Ready for the single CONFIRM-ALL review once no job is still queued/opening/
    // filling — every job has settled into ready_for_review / needs_human / done / error.
    const allSettled = jobs.length > 0 && jobs.every((j) => SETTLED_STATES.has(j.state));
    return {
      total: jobs.length,
      byState,
      filled,
      unmatched,
      uploaded,
      blocked,
      ready: byState.ready_for_review,
      needsHuman: byState.needs_human,
      done: byState.done,
      error: byState.error,
      allSettled,
    };
  }

  // ── the orchestrator (browser side-effects injected) ─────────────────────────
  class PortalOrchestrator {
    // opts:
    //   cap         concurrency cap (default 3)
    //   createTab   async (entryUrl) => tabId          [default chrome.tabs.create]
    //   fillTab     async (tabId, job) => progress     [default QC_FILL_MAP message]
    //   reportStatus async (job) => void               [default APPLY_STATUS message]
    //   onChange    (jobs) => void   UI hook, called on every state change
    constructor(opts = {}) {
      this.cap = opts.cap && opts.cap > 0 ? opts.cap : DEFAULT_CAP;
      this.jobs = [];
      this._createTab = opts.createTab || defaultCreateTab;
      this._fillTab = opts.fillTab || defaultFillTab;
      this._reportStatus = opts.reportStatus || defaultReportStatus;
      this._onChange = opts.onChange || (() => {});
      this._byTab = new Map(); // tabId → job.id
    }

    start(jobs) {
      this.jobs = (jobs || []).map((j) => Object.assign({ state: "queued", progress: null }, j));
      this._emit();
      this._pump();
      return this.jobs;
    }

    summary() { return summarize(this.jobs); }

    // Open as many queued jobs as free slots allow, then drive each.
    _pump() {
      const toStart = nextToStart(this.jobs, this.cap, activeCount(this.jobs));
      for (const job of toStart) this._open(job);
    }

    async _open(job) {
      this._set(job.id, { state: "opening" });
      let tabId;
      try {
        tabId = await this._createTab(job.entryUrl);
      } catch (e) {
        this._set(job.id, { state: "error", progress: { blocked: "open_failed" } });
        this._pump();
        return;
      }
      this._byTab.set(tabId, job.id);
      this._set(job.id, { tabId, state: "filling" });
      try {
        const progress = await this._fillTab(tabId, this._job(job.id));
        const cur = this._job(job.id);
        const next = applyProgress(cur, progress);
        // No block → filled and parked at Review. Never auto-submits.
        if (next.state !== "needs_human") next.state = "ready_for_review";
        this._replace(next);
        await this._report(next);
      } catch (e) {
        this._set(job.id, { state: "error", progress: { blocked: String((e && e.message) || e) } });
        await this._report(this._job(job.id));
      }
      // A finished / blocked job frees a slot → start the next queued one.
      this._pump();
    }

    // Content script signalled the human gate is cleared → resume that tab.
    async resume(jobId) {
      const job = this._job(jobId);
      if (!job || job.state !== "needs_human") return;
      this._set(jobId, { state: "filling" });
      try {
        const progress = await this._fillTab(job.tabId, this._job(jobId));
        const next = applyProgress(this._job(jobId), progress);
        if (next.state !== "needs_human") next.state = "ready_for_review";
        this._replace(next);
        await this._report(next);
      } catch (e) {
        this._set(jobId, { state: "error", progress: { blocked: String((e && e.message) || e) } });
      }
      this._pump();
    }

    // ── internal state helpers ─────────────────────────────────────────────────
    _job(id) { return this.jobs.find((j) => j.id === id); }
    _replace(next) {
      const i = this.jobs.findIndex((j) => j.id === next.id);
      if (i >= 0) this.jobs[i] = next;
      this._emit();
    }
    _set(id, patch) {
      const i = this.jobs.findIndex((j) => j.id === id);
      if (i >= 0) { this.jobs[i] = Object.assign({}, this.jobs[i], patch); this._emit(); }
    }
    _emit() { try { this._onChange(this.jobs.slice()); } catch (e) { /* UI hook must not break the queue */ } }
    async _report(job) {
      try { await this._reportStatus(job); } catch (e) { /* status mirroring is best-effort */ }
    }
  }

  // ── default browser side-effects (only referenced at call time) ──────────────
  async function defaultCreateTab(entryUrl) {
    const tab = await chrome.tabs.create({ url: entryUrl, active: false });
    return tab.id;
  }
  async function defaultFillTab(tabId, job) {
    // content.js QC_FILL_MAP replies { filled, matched, uploaded, ... }; the
    // orchestrator only needs the progress-shaped fields.
    const r = await chrome.tabs.sendMessage(tabId, { type: "QC_FILL_MAP", job });
    const p = r || {};
    return {
      filled: p.filled || 0,
      unmatched: p.unmatched || (typeof p.matched === "number" ? Math.max(0, (p.captured || 0) - p.matched) : 0),
      uploaded: p.uploaded || 0,
      blocked: p.blocked || undefined,
    };
  }
  async function defaultReportStatus(job) {
    // Mirror job state to Convex applyJobs via the service worker (Bearer path).
    return chrome.runtime.sendMessage({
      type: "APPLY_STATUS",
      jobId: job.id,
      system: job.system,
      externalId: job.externalId,
      state: job.state,
      progress: job.progress || null,
    });
  }

  const api = { PortalOrchestrator, nextToStart, summarize, activeCount, applyProgress, DEFAULT_CAP };
  if (typeof module !== "undefined" && module.exports) module.exports = api;
  if (root) root.QCOrchestrator = api;
})(typeof globalThis !== "undefined" ? globalThis : this);
