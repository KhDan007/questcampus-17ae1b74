// Content script — the page-side worker. The sidebar drives it via messages:
//   QC_CAPTURE          -> serialize every fillable widget on this screen
//   QC_APPLY            -> apply LLM {i,value} decisions + attach documents
//   QC_FILL             -> deterministic fallback fill (no backend)
//   QC_CONTINUE_INFO    -> is there a "Continue" here?
//   QC_CLICK_CONTINUE   -> click Continue, wait for the next screen
//   QC_HIGHLIGHT        -> outline where the user must click
//   QC_SECTIONS         -> Common App sections present on this page
//   QC_GOTO_SECTION     -> navigate to a section
// Never touches password fields. Never final-submits.

(function () {
  // Chrome MV3 shim — keep the shared content-script code identical to Firefox.
  const browser = globalThis.browser ?? chrome;

  // Presence marker so questcampus.space pages can detect the extension is
  // installed (data attribute, not a global — survives content-script
  // isolated-world separation from the page's own JS).
  if (/(^|\.)questcampus\.space$/i.test(location.hostname) || location.hostname === "localhost") {
    try {
      document.documentElement.setAttribute("data-qc-extension", chrome.runtime.getManifest().version);
    } catch {
      /* non-fatal */
    }
  }

  // ── labels + visibility ────────────────────────────────────────────────────
  function norm(s) {
    const str = typeof s === "string" ? s : (s == null ? "" : String(s));
    return str.toLowerCase().replace(/\s+/g, " ").replace(/[*:_]/g, " ").replace(/\s+/g, " ").trim();
  }

  // Common App wraps each field in <ca-control-wrapper> whose question text lives in a
  // <ca-control-wrapper-label class="control__label"> SIBLING of the control (not an
  // ancestor <label> nor a [for]=), so the generic heuristics below miss it entirely.
  // This is the authoritative label; resolve it first everywhere.
  function caWrapLabel(el) {
    const w = el.closest && el.closest("ca-control-wrapper, [class*=control-wrapper]");
    if (!w) return "";
    const l = w.querySelector(".control__label, ca-control-wrapper-label");
    return l ? (l.textContent || "").replace(/\s+/g, " ").trim() : "";
  }

  function textOf(el) {
    // Label text minus any nested control text (so a wrapping <label> around a
    // radio/checkbox yields just the option words).
    const clone = el.cloneNode(true);
    clone.querySelectorAll("input,select,textarea,button").forEach((n) => n.remove());
    return (clone.textContent || "").replace(/\s+/g, " ").trim();
  }

  function labelFor(el) {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l && l.textContent.trim()) return l.textContent.trim();
    }
    const wrap = el.closest("label");
    if (wrap) { const t = textOf(wrap); if (t) return t; }
    const aria = el.getAttribute("aria-label");
    if (aria) return aria.trim();
    const lb = el.getAttribute("aria-labelledby");
    if (lb) {
      const t = lb.split(/\s+/).map((i) => document.getElementById(i)?.textContent).filter(Boolean).join(" ").trim();
      if (t) return t;
    }
    const cw = caWrapLabel(el); if (cw) return cw; // Common App .control__label
    const cont = el.closest("[class*=field],[class*=question],[class*=form-group],fieldset,div");
    const q = cont && cont.querySelector("label,legend,[class*=label]");
    if (q && q !== el && q.textContent.trim()) return q.textContent.trim();
    return (el.getAttribute("placeholder") || el.getAttribute("name") || "").trim();
  }

  // Group heading for a radio/checkbox set (fieldset legend, aria group, nearest heading).
  function groupLabel(el) {
    const fs = el.closest("fieldset");
    const lg = fs && fs.querySelector("legend");
    if (lg && lg.textContent.trim()) return lg.textContent.trim();
    const grp = el.closest("[role=radiogroup],[role=group]");
    if (grp) {
      const al = grp.getAttribute("aria-label");
      if (al) return al.trim();
      const lb = grp.getAttribute("aria-labelledby");
      const t = lb && document.getElementById(lb)?.textContent;
      if (t) return t.trim();
    }
    const cont = el.closest("[class*=field],[class*=question],[class*=form-group],div");
    const q = cont && cont.querySelector("label,legend,[class*=label],h1,h2,h3,h4");
    if (q && q.textContent.trim()) return q.textContent.trim();
    return (el.getAttribute("name") || "").trim();
  }

  function optLabel(el) {
    if (el.id) {
      const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`);
      if (l && l.textContent.trim()) return l.textContent.trim();
    }
    const wrap = el.closest("label");
    if (wrap) { const t = textOf(wrap); if (t) return t; }
    return (el.getAttribute("aria-label") || el.value || "").trim();
  }

  function visible(el) {
    const s = getComputedStyle(el);
    if (s.display === "none" || s.visibility === "hidden" || s.opacity === "0") return false;
    const r = el.getBoundingClientRect();
    return r.width > 2 && r.height > 2;
  }

  // ── setters (React-safe) ────────────────────────────────────────────────────
  function setNative(el, value) {
    const proto =
      el.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype
      : el.tagName === "SELECT" ? HTMLSelectElement.prototype
      : HTMLInputElement.prototype;
    const desc = Object.getOwnPropertyDescriptor(proto, "value");
    desc.set.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    el.dispatchEvent(new Event("blur", { bubbles: true }));
  }

  function pickOption(options, value) {
    const nv = norm(value);
    let hit = options.find((o) => norm(o) === nv);
    if (!hit && nv) hit = options.find((o) => o && (norm(o).includes(nv) || nv.includes(norm(o))));
    return hit || null;
  }

  function setSelect(el, value) {
    const nv = norm(value);
    let opt = null;
    for (const o of el.options) if (norm(o.textContent) === nv || norm(o.value) === nv) { opt = o; break; }
    if (!opt && nv) for (const o of el.options) if (norm(o.textContent) && (norm(o.textContent).includes(nv) || nv.includes(norm(o.textContent)))) { opt = o; break; }
    if (!opt) return false;
    el.value = opt.value;
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
    return true;
  }

  // ── capture: every fillable widget, incl. CUSTOM/HIDDEN controls ─────────────
  // Common App (and most React apps) render radios/checkboxes as a visually-hidden
  // native <input> + a styled <label>, and "dropdowns" as custom comboboxes — none
  // of which are a visible <input>/<select>. We must reach them via labels + ARIA.
  let REG = []; // index -> slot describing how to fill

  // Laxer than visible(): the element is in the render tree (may be sr-only 1px).
  function renders(el) {
    const s = getComputedStyle(el);
    return s.display !== "none" && s.visibility !== "hidden";
  }
  function labelElFor(el) {
    if (el.id) { const l = document.querySelector(`label[for="${CSS.escape(el.id)}"]`); if (l) return l; }
    return el.closest("label");
  }
  // An option/control's OWN short label (not sibling help text).
  function shortLabel(el) {
    const l = labelElFor(el);
    let t = l ? textOf(l) : (el.getAttribute("aria-label") || el.value || el.textContent || "");
    return (t || "").replace(/\s+/g, " ").trim().slice(0, 90);
  }
  // The question/group label (fieldset legend, ARIA group, nearest block label),
  // capped so long help paragraphs don't drown the actual question.
  function questionLabel(el) {
    const cwq = caWrapLabel(el); if (cwq) return cwq.slice(0, 130); // Common App .control__label
    const fs = el.closest("fieldset");
    const lg = fs && fs.querySelector("legend");
    let t = lg && lg.textContent;
    if (!t) {
      const grp = el.closest("[role=radiogroup],[role=group]");
      if (grp) {
        t = grp.getAttribute("aria-label");
        const lb = grp.getAttribute("aria-labelledby");
        if (!t && lb) t = document.getElementById(lb)?.textContent;
      }
    }
    if (!t) {
      const cont = el.closest("[class*=field],[class*=question],[class*=form-group],[class*=form-item]") || el.parentElement;
      const q = cont && cont.querySelector("label,legend,h1,h2,h3,h4,[class*=label],[class*=question]");
      if (q) t = q.textContent;
    }
    return (t || "").replace(/\s+/g, " ").trim().slice(0, 130);
  }
  // Nearby helper/format text (e.g. "Date uses 'month day, year'") so the LLM can
  // match the format the field expects.
  function hintFor(el) {
    const db = el.getAttribute("aria-describedby");
    if (db) { const t = db.split(/\s+/).map((i) => document.getElementById(i)?.textContent).filter(Boolean).join(" ").trim(); if (t) return t.slice(0, 110); }
    const cont = el.closest("[class*=field],[class*=form-group],[class*=form-item]");
    const h = cont && cont.querySelector("[class*=help],[class*=hint],[class*=description],small");
    if (h && h.textContent.trim()) return h.textContent.replace(/\s+/g, " ").trim().slice(0, 110);
    return "";
  }
  function comboLabel(el) {
    const cwc = caWrapLabel(el); if (cwc) return cwc.slice(0, 130); // Common App .control__label
    const al = el.getAttribute("aria-label"); if (al) return al.trim().slice(0, 130);
    const lb = el.getAttribute("aria-labelledby");
    if (lb) { const t = lb.split(/\s+/).map((i) => document.getElementById(i)?.textContent).filter(Boolean).join(" ").trim(); if (t) return t.slice(0, 130); }
    return questionLabel(el);
  }

  function captureFields() {
    REG = [];
    const out = [];
    const nativeSeen = new Set();
    const groups = {}; // key -> { name, label, options:[{label, el, role}] }
    const addRadio = (key, label, opt) => { if (!groups[key]) groups[key] = { name: key.slice(0, 60), label, options: [] }; groups[key].options.push(opt); };

    // 1) native inputs/selects/textareas (radios/checkboxes captured even if sr-only)
    for (const el of document.querySelectorAll("input, select, textarea")) {
      const type = (el.getAttribute("type") || el.tagName).toLowerCase();
      if (["hidden", "submit", "button", "reset", "image", "password", "file", "range", "color"].includes(type)) continue;
      if (el.disabled || el.readOnly) continue;

      if (type === "radio" || type === "checkbox") {
        const lab = labelElFor(el);
        // Keep sr-only inputs that have a visible label; drop truly hidden templates.
        if (!renders(el)) continue;
        if (!visible(el) && !(lab && visible(lab))) continue;
        nativeSeen.add(el);
        if (type === "radio") {
          const key = el.name || ("q:" + questionLabel(el));
          addRadio(key, questionLabel(el), { label: shortLabel(el) || el.value || "", el, role: false });
        } else {
          const i = REG.length; REG.push({ el, kind: "checkbox" });
          out.push({ i, kind: "checkbox", label: shortLabel(el) || questionLabel(el), name: el.name || "", current: el.checked ? "true" : "false" });
        }
        continue;
      }
      // Native <select> — capture even when visually hidden. Common App overlays a
      // custom dropdown UI on a real, sr-only <select>; setting .value still drives
      // React, and the visible UI follows.
      if (el.tagName === "SELECT") {
        if (!renders(el)) continue;
        nativeSeen.add(el);
        const i = REG.length; REG.push({ el, kind: "select", combo: false });
        const options = [...el.options].map((o) => o.textContent.trim()).filter((t) => t && !/^(select|choose|please|--|\s*$)/i.test(t));
        out.push({ i, kind: "select", label: labelFor(el), name: el.name || "", options, current: el.selectedIndex >= 0 ? (el.options[el.selectedIndex]?.textContent.trim() || "") : "" });
        continue;
      }
      if (!visible(el)) continue;
      const baseLabel = labelFor(el);
      // Skip site search boxes (e.g. Common App's "Search FAQs") — not form fields.
      const meta = norm(baseLabel + " " + (el.getAttribute("placeholder") || "") + " " + (el.getAttribute("aria-label") || "") + " " + (el.name || "") + " " + (el.id || ""));
      if (el.closest("[role=search]") || /\bsearch\b/.test(meta)) continue;
      // ARIA autocomplete comboboxes are text inputs but behave as dropdowns
      // (Common App: <input role=combobox aria-autocomplete=list aria-haspopup=listbox>).
      // Route them to the combobox handler (type → pick option), not plain text.
      if (el.getAttribute("role") === "combobox" || el.getAttribute("aria-autocomplete") === "list" || el.getAttribute("aria-haspopup") === "listbox") {
        nativeSeen.add(el);
        const i = REG.length; REG.push({ el, kind: "select", combo: true });
        out.push({ i, kind: "select", label: baseLabel, name: el.name || "", options: [], current: el.value || "" });
        continue;
      }
      nativeSeen.add(el);
      const kind = el.tagName === "TEXTAREA" ? "textarea" : type === "date" ? "date" : type === "number" ? "number" : "text";
      const i = REG.length; REG.push({ el, kind });
      const hint = hintFor(el);
      out.push({ i, kind, label: hint ? `${baseLabel} — ${hint}` : baseLabel, name: el.name || "", current: el.value || "" });
    }

    // 2) ARIA custom controls with no native input we already captured
    for (const el of document.querySelectorAll("[role=radio],[role=checkbox],[role=switch],[role=combobox],[aria-haspopup=listbox]")) {
      if (nativeSeen.has(el)) continue;
      if (el.querySelector && el.querySelector("input,select,textarea")) continue; // wrapper of a native control
      if (!visible(el)) continue;
      const cls2 = typeof el.className === "string" ? el.className : "";
      if (/nav-item|help-topic|mat-icon-button/.test(cls2)) continue;
      const pop2 = el.getAttribute("aria-haspopup");
      if (pop2 === "dialog" || pop2 === "menu") continue;
      const role = el.getAttribute("role");
      const isCombo = role === "combobox" || el.getAttribute("aria-haspopup") === "listbox";
      if (isCombo) {
        const i = REG.length; REG.push({ el, kind: "select", combo: true });
        out.push({ i, kind: "select", label: comboLabel(el), name: el.getAttribute("name") || "", options: [], current: (el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 60), html: el.outerHTML.slice(0, 500) });
      } else if (role === "radio") {
        const grp = el.closest("[role=radiogroup]");
        const key = "r:" + ((grp && (grp.getAttribute("aria-label") || grp.getAttribute("aria-labelledby"))) || questionLabel(el));
        addRadio(key, questionLabel(el), { label: shortLabel(el) || (el.getAttribute("aria-label") || el.textContent || "").trim().slice(0, 90), el, role: true });
      } else {
        const i = REG.length; REG.push({ el, kind: "checkbox", role: true });
        out.push({ i, kind: "checkbox", label: shortLabel(el) || questionLabel(el), name: "", current: el.getAttribute("aria-checked") === "true" ? "true" : "false" });
      }
    }

    // 2b-ng) ng-select (the Common App dropdown). Its inner <input role=combobox> may
    // be 0x0 until focused, so section 1 can miss it — capture the <ng-select> wrapper
    // itself (skipping ones whose inner input was already captured). We store the
    // wrapper as the fill target; applyCombo routes it through the ng-select handler.
    for (const el of document.querySelectorAll("ng-select")) {
      if (nativeSeen.has(el)) continue;
      const inner = el.querySelector("input");
      if (inner && nativeSeen.has(inner)) continue; // already captured via section 1
      if (!visible(el)) continue;
      const cls2ng = typeof el.className === "string" ? el.className : "";
      if (/nav-item|help-topic/.test(cls2ng)) continue;
      nativeSeen.add(el);
      if (inner) nativeSeen.add(inner);
      const i = REG.length; REG.push({ el, kind: "select", combo: true });
      const cur = (el.querySelector(".ng-value-label")?.textContent || "").replace(/\s+/g, " ").trim().slice(0, 60);
      out.push({ i, kind: "select", label: comboLabel(el), name: "", options: [], current: cur });
    }

    // 2b) Real form dropdowns: Angular Material <mat-select> / Forge <forge-select>
    // and genuine listbox comboboxes — explicitly EXCLUDING nav, help accordions,
    // and dialog/menu triggers (which are buttons with aria-expanded, not fields).
    for (const el of document.querySelectorAll("mat-select,forge-select,forge-autocomplete,[role=combobox][aria-haspopup=listbox]")) {
      if (nativeSeen.has(el)) continue;
      const cls = typeof el.className === "string" ? el.className : "";
      if (/nav-item|help-topic|mat-icon-button/.test(cls)) continue;
      const pop = el.getAttribute("aria-haspopup");
      if (pop === "dialog" || pop === "menu") continue;
      if (!visible(el)) continue;
      nativeSeen.add(el);
      const i = REG.length; REG.push({ el, kind: "select", combo: true });
      out.push({ i, kind: "select", label: comboLabel(el), name: "", options: [], current: (el.textContent || "").replace(/\s+/g, " ").trim().slice(0, 60) });
    }

    // 2c) Rich-text editors (essays, "additional info") are contenteditable divs,
    // not <textarea> — capture them so prose fields get filled too.
    for (const el of document.querySelectorAll("[contenteditable]:not([contenteditable=false]),[role=textbox]")) {
      if (nativeSeen.has(el)) continue;
      if (el.querySelector && el.querySelector("input,textarea,[contenteditable]")) continue;
      if (!visible(el)) continue;
      nativeSeen.add(el);
      const i = REG.length; REG.push({ el, kind: "richtext" });
      out.push({ i, kind: "textarea", label: labelFor(el) || questionLabel(el), name: "", current: (el.textContent || "").slice(0, 40) });
    }

    // 2d) Institution lookup triggers ("Find your school", "Add a college") — a
    // dialog-based search picker. Captured as kind "lookup" so the planner supplies
    // the school NAME and applyLookup drives the modal search→pick→confirm flow.
    const schoolRe = /find (your )?(school|college|univers)|add (a |an )?(college|school|univers)|search (for )?(a )?(college|school|univers)|look ?up (your )?(school|college)/i;
    for (const el of document.querySelectorAll("button, a[role=button], [role=button]")) {
      if (nativeSeen.has(el) || !visible(el)) continue;
      const t = (el.textContent || el.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
      if (!t || t.length > 60 || !schoolRe.test(t)) continue;
      if (el.closest("nav, [role=navigation], header")) continue;
      nativeSeen.add(el);
      // Label the lookup by its FIELD wrapper ("College lookup*") when present, not the
      // button text ("Find college") — the map keys the field by the wrapper label, so
      // using the button text made pickField miss it and the college stayed blank.
      const wlab = caWrapLabel(el);
      const i = REG.length; REG.push({ el, kind: "lookup" });
      out.push({ i, kind: "lookup", label: (wlab || t).slice(0, 120), name: "", current: "" });
    }

    // 3) emit radio groups
    for (const key in groups) {
      const g = groups[key];
      if (!g.options.length) continue;
      const i = REG.length; REG.push({ kind: "radio", options: g.options });
      const current = g.options.find((o) => (o.role ? o.el.getAttribute("aria-checked") === "true" : o.el.checked))?.label || "";
      out.push({ i, kind: "radio", label: g.label, name: g.name, options: g.options.map((o) => o.label), current });
    }
    // DIAGNOSTIC: attach the real outerHTML of every field so the exact widget
    // markup (mat-select vs mat-autocomplete vs datepicker) is inspectable.
    for (const f of out) {
      if (f.html) continue;
      const slot = REG[f.i];
      const el = slot && (slot.el || (slot.options && slot.options[0] && slot.options[0].el));
      if (el) { try { f.html = el.outerHTML.slice(0, 300); } catch (e) { /* noop */ } }
    }
    return out;
  }

  // Click a choice the way a user would — the styled label for a native input,
  // else the element itself (custom ARIA control).
  function clickChoice(el, isRole) {
    if (!isRole) { const lab = labelElFor(el); if (lab && visible(lab)) { lab.click(); return; } }
    el.click();
  }
  function isChecked(el, isRole) {
    return isRole ? el.getAttribute("aria-checked") === "true" : !!el.checked;
  }

  // Custom combobox handling — the fragile part. Common App-style dropdowns often
  // ignore a bare .click() on options (they listen for mousedown), and render the
  // menu asynchronously in a portal. So: open with a real event sequence, POLL for
  // options, pick with mousedown+click, and VERIFY the value actually took (so a
  // "filled" result is honest, not optimistic).
  function fireSeq(el) {
    // ng-select (and Forge) commit a selection on the POINTER sequence, not a bare
    // click — pointerdown/pointerup are required or the option never registers even
    // though it renders. Dispatching MouseEvents with pointer type names fires those
    // listeners. Searchable ng-selects then show the value in their <input>, which
    // comboShown() also reads.
    for (const t of ["pointerdown", "mousedown", "pointerup", "mouseup", "click"]) el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window }));
  }
  // The Common App form is built on ng-select (Angular). Given any captured element
  // (the inner <input role=combobox> or the wrapper), return the enclosing <ng-select>.
  function ngWrapOf(el) {
    if (!el) return null;
    if (el.matches && el.matches("ng-select")) return el;
    return (el.closest && el.closest("ng-select")) || null;
  }
  function openControl(el) {
    try { el.scrollIntoView({ block: "center" }); } catch (e) { /* noop */ }
    try { (el.querySelector && el.querySelector("input") || el).focus(); } catch (e) { /* noop */ }
    // ng-select (Common App): the panel opens on a mousedown on .ng-select-container,
    // NOT a click on the wrapper or a keystroke — this is the fix for the opts=0 bug.
    const ng = ngWrapOf(el);
    if (ng) {
      const cont = ng.querySelector(".ng-select-container") || ng;
      fireSeq(cont);
      return;
    }
    // Angular Material <mat-select> and Forge selects listen on an inner trigger
    // element, not the custom element itself — firing on the wrapper opens nothing.
    // Fire on the trigger child when present, else the element.
    let target = el;
    if (el.querySelector) {
      const trig = el.querySelector(".mat-mdc-select-trigger, .mat-select-trigger, [class*=trigger], [aria-haspopup]");
      if (trig) target = trig;
    }
    fireSeq(target);
  }
  // Read the option elements of the CURRENTLY-OPEN dropdown. `scope` (an <ng-select>
  // wrapper) restricts the read to THAT control's own panel — critical because
  // Common App renders every ng-select's .ng-dropdown-panel as a child of the
  // element itself, and reading globally leaks options across controls (the famous
  // "567 languages" = 3 panels' worth bug). Angular Material's panels live in
  // .cdk-overlay-container, so those stay global.
  function optionEls(scope) {
    if (scope) {
      const panel = scope.querySelector(".ng-dropdown-panel");
      const opts = panel ? [...panel.querySelectorAll("[role=option], .ng-option")] : [];
      return [...new Set(opts)].filter((o) => visible(o) && (o.textContent || "").trim());
    }
    const panels = [...document.querySelectorAll(
      ".ng-dropdown-panel, .cdk-overlay-pane, .cdk-overlay-container [role=listbox], [role=listbox], mat-autocomplete, .mat-mdc-autocomplete-panel, .mat-mdc-select-panel",
    )].filter(visible);
    let opts = [];
    for (const p of panels) opts.push(...p.querySelectorAll("mat-option, [role=option], .ng-option, li"));
    if (!opts.length) {
      const ov = document.querySelector(".cdk-overlay-container");
      if (ov) opts = [...ov.querySelectorAll("mat-option, [role=option]")];
    }
    // de-dup + keep only visible, non-empty
    return [...new Set(opts)].filter((o) => visible(o) && (o.textContent || "").trim());
  }
  async function waitOptions(ms, scope) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      const o = optionEls(scope);
      if (o.length) { await sleep(150); return optionEls(scope); }
      await sleep(120);
    }
    return [];
  }
  function pickOpt(opts, nv) {
    if (!nv) return null;
    // 1. exact
    let hit = opts.find((o) => norm(o.textContent) === nv);
    if (hit) return hit;
    // 2. substring either direction
    hit = opts.find((o) => { const t = norm(o.textContent); return t && (t.includes(nv) || nv.includes(t)); });
    if (hit) return hit;
    // 3. token-overlap score — matches "Bachelor's degree" ↔ "bachelor's (ba, bs)",
    //    "less than high school" ↔ "some high/secondary school", etc.
    const vw = nv.split(/[^a-z0-9]+/).filter((w) => w.length > 2);
    if (!vw.length) return null;
    let best = null, bestScore = 0;
    for (const o of opts) {
      const t = norm(o.textContent);
      const tw = t.split(/[^a-z0-9]+/).filter((w) => w.length > 2);
      if (!tw.length) continue;
      let shared = 0;
      for (const w of vw) if (tw.some((x) => x === w || x.startsWith(w) || w.startsWith(x))) shared++;
      const score = shared / vw.length;
      if (score > bestScore) { bestScore = score; best = o; }
    }
    return bestScore >= 0.5 ? best : null;
  }
  function comboShown(el) {
    // ng-select shows the chosen value in a .ng-value-label chip (the search input
    // clears after picking), so read the wrapper's rendered value, not just the input.
    const ng = ngWrapOf(el);
    if (ng) {
      const chip = [...ng.querySelectorAll(".ng-value-label")].map((v) => v.textContent || "").join(" ");
      const iv = ng.querySelector("input")?.value || "";
      return norm(chip + " " + iv);
    }
    const iv = el.matches("input") ? el.value : el.querySelector("input")?.value;
    return norm((el.textContent || "") + " " + (iv || ""));
  }
  function comboExpanded(el) {
    const ng = ngWrapOf(el);
    if (ng) return ng.classList.contains("ng-select-opened");
    return el.getAttribute("aria-expanded") === "true" || !!(el.querySelector && el.querySelector("[aria-expanded=true]"));
  }
  // A real selection = the value is shown AND the option panel has closed. Typing
  // alone leaves text in the input with the panel still open — not a valid pick.
  async function verifyCombo(el, nv, ms) {
    const t0 = Date.now();
    while (Date.now() - t0 < ms) {
      if (comboShown(el).includes(nv) && !comboExpanded(el)) return true;
      await sleep(120);
    }
    return false;
  }
  // Pick an option inside an OPEN ng-select the way a user does: mousedown+click on
  // the option row. Options are plain <div role=option> inside .ng-dropdown-panel.
  function chooseNgOption(hit) {
    try { hit.scrollIntoView({ block: "nearest" }); } catch (e) { /* noop */ }
    fireSeq(hit);
  }
  // ng-select fill: the Common App path. Open on the container, read the FULL option
  // list scoped to this control (ng-select renders all options at once — no virtual
  // scroll for these lists), pick by value/token, click, verify via the value chip.
  // When the raw list is huge or lazy, type the value to filter, then pick.
  async function applyNgSelect(ng, value) {
    const nv = norm(value);
    if (comboShown(ng).includes(nv) && !comboExpanded(ng)) return true; // already set
    const inp = ng.querySelector("input");
    openControl(ng);
    let opts = await waitOptions(2200, ng);
    // The option list may not have hydrated on the first open (Activities renders 10
    // searchable selects whose data loads ~7s in) — an empty panel means "try again", so
    // close and reopen a few times before falling back to type-to-filter.
    for (let retry = 0; retry < 4 && !opts.length; retry++) {
      try { (inp || ng).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) { /* noop */ }
      await sleep(700);
      openControl(ng);
      opts = await waitOptions(2500, ng);
    }
    let hit = pickOpt(opts, nv);
    // Not found in the rendered list -> type to filter (handles server-backed lists and
    // lists longer than the initial render), then re-read + pick.
    if (!hit && inp) {
      setNative(inp, value);
      await sleep(350);
      opts = await waitOptions(1600, ng);
      hit = pickOpt(opts, nv);
      if (!hit) { // widen: filter by just the first word
        const first = String(value).split(/[ ,(/]/)[0];
        setNative(inp, first);
        await sleep(350);
        opts = await waitOptions(1400, ng);
        hit = pickOpt(opts, nv) || pickOpt(opts, norm(first));
      }
    }
    if (hit) {
      chooseNgOption(hit);
      // Multi-select (e.g. Testing "indicate all tests") keeps the panel open; accept
      // when the option flips selected, then close. Single-select closes on pick.
      const multi = !!(ng.querySelector("[aria-multiselectable=true]") || ng.classList.contains("ng-select-multiple"));
      if (multi) {
        await sleep(180);
        const ok = comboShown(ng).includes(nv) || hit.classList.contains("ng-option-selected") || hit.getAttribute("aria-selected") === "true";
        try { (inp || ng).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) { /* noop */ }
        return ok;
      }
      if (await verifyCombo(ng, nv, 1200)) return true;
    }
    // Give up cleanly: close the panel, leave the field for the user.
    try { (inp || ng).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.body.click(); } catch (e) { /* noop */ }
    return false;
  }

  async function applyCombo(el, value) {
    if (el.tagName === "SELECT") return setSelect(el, value);
    // ng-select (Common App) has its own reliable open/read/pick path.
    const ng = ngWrapOf(el);
    if (ng) return applyNgSelect(ng, value);
    // Inline mat-autocomplete (the address typeahead): type → STRICT-pick a suggestion,
    // never the "I don't see my address" placeholder. ng-select inputs were handled above;
    // a plain input advertising aria-autocomplete="list" is the address typeahead.
    if (el.matches && el.matches("input[aria-autocomplete=list]")) {
      return applyInlineAutocomplete(el, value);
    }
    const nv = norm(value);
    if (comboShown(el).includes(nv) && !comboExpanded(el)) return true; // already set
    const inp = el.matches("input") ? el : el.querySelector("input");
    openControl(el);
    await sleep(200);
    if (inp) setNative(inp, value); // typeahead: filter the list (may hit a server)
    let opts = await waitOptions(2600);
    // opts=0 → the panel never opened (common for <mat-select>, which is a click-
    // to-open menu with no typeahead input). Retry with a plain click on the
    // trigger, then a click on the element itself.
    if (!opts.length) {
      for (const t of [el.querySelector && el.querySelector(".mat-mdc-select-trigger, .mat-select-trigger"), el]) {
        if (!t) continue;
        try { t.click(); } catch (e) { /* noop */ }
        await sleep(200);
        opts = await waitOptions(1600);
        if (opts.length) break;
      }
    }
    // DIAGNOSTIC: record the live option overlay so the exact option markup is known.
    try {
      const ov = document.querySelector(".cdk-overlay-container") || document.querySelector("[role=listbox]");
      comboDebug.push({
        q: ((el.getAttribute("aria-label") || el.id || el.getAttribute("placeholder") || "")).slice(0, 30),
        val: String(value).slice(0, 20),
        opts: opts.length,
        sample: opts.slice(0, 6).map((o) => norm(o.textContent).slice(0, 24)),
        ov: ov ? ov.innerHTML.replace(/\s+/g, " ").slice(0, 600) : "(no cdk-overlay/listbox)",
      });
    } catch (e) { /* noop */ }
    let hit = pickOpt(opts, nv);
    if (hit) {
      try { hit.scrollIntoView({ block: "nearest" }); } catch (e) { /* noop */ }
      // Multi-select listboxes (e.g. Testing "indicate all tests to report") keep
      // the panel OPEN after a pick, so verifyCombo's "panel closed" check never
      // passes. Accept the pick when the option flips to aria-selected, then close.
      const multi = !!(hit.closest && hit.closest("[aria-multiselectable=true]"));
      fireSeq(hit);
      if (multi) {
        await sleep(160);
        if (hit.getAttribute("aria-selected") === "true" || hit.classList.contains("mdc-list-item--selected")) {
          try { (inp || el).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.body.click(); } catch (e) { /* noop */ }
          return true;
        }
      }
      if (await verifyCombo(el, nv, 1000)) return true;
    }
    // retry with just the first word (widens the filtered set), then keyboard-select
    if (inp) {
      const first = value.split(/[ ,(/]/)[0];
      setNative(inp, first);
      await sleep(300);
      opts = await waitOptions(1200);
      hit = pickOpt(opts, nv) || pickOpt(opts, norm(first));
      if (hit) { fireSeq(hit); if (await verifyCombo(el, nv, 900)) return true; }
      inp.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true }));
      await sleep(160);
      inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true }));
      if (await verifyCombo(el, nv, 700)) return true;
    }
    try { (inp || el).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.body.click(); } catch (e) { /* noop */ }
    return false;
  }

  // "Find your school / Add a college" is a MULTI-CLICK dialog flow, not a field:
  // click the trigger → a modal opens with its OWN search box → type the school →
  // wait for result rows → click the match → confirm inside the dialog. We treat
  // it as kind "lookup" so the LLM just supplies the institution name.
  function overlayRoot() {
    // Prefer the real Material dialog; a hidden cookie-consent modal (.cky-modal) also
    // matches "[class*=modal]" and used to win, breaking every lookup (0 inputs found).
    const cands = [...document.querySelectorAll("mat-dialog-container, .mat-mdc-dialog-container, forge-dialog, ca-modal, [role=dialog], [role=alertdialog], .cdk-overlay-pane, .modal, [class*=modal]")];
    return cands.find((d) => visible(d) && !/\bcky|cookie|consent/i.test(d.className || "") && !/cookie|consent preferences/i.test((d.textContent || "").slice(0, 60))) || null;
  }
  // The label text sitting immediately before/above an input (for choosing the
  // right box in a multi-input dialog).
  function nearLabel(el) {
    const l = labelElFor(el);
    if (l) return norm(textOf(l));
    const wrap = el.closest("[class*=field],[class*=form-group],[class*=input]") || el.parentElement;
    const lb = wrap && wrap.querySelector("label,[class*=label]");
    return lb ? norm(lb.textContent) : "";
  }
  function closeOverlay() {
    const root = overlayRoot();
    if (!root) return;
    const x = [...root.querySelectorAll("button,[role=button]")].find((b) => visible(b) && /close|cancel|×|✕/i.test((b.getAttribute("aria-label") || b.textContent || "")));
    try { if (x) x.click(); } catch (e) { /* noop */ }
    try { document.dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); } catch (e) { /* noop */ }
  }
  // Inline mat-autocomplete (Common App's permanent-address typeahead): type into the
  // field, wait for the .mat-mdc-autocomplete-panel, and STRICT-pick the matching option.
  // This is NOT a dialog like the school lookup — the suggestions drop inline. A real
  // address matches; a placeholder like "I don't see my address in this list" is not a
  // real hit, so we leave the field for the user rather than commit a wrong pick.
  async function applyInlineAutocomplete(inp, value) {
    // The autocomplete over-specifies badly: typing "street, city, STATE, zip" returns NO
    // match, but "street, city" resolves ("48 University Pl, Princeton NJ 08540"). Query
    // with the first two comma parts (street, city). Type character-by-character so the
    // debounced Places lookup actually fires.
    const parts = String(value).split(",").map((s) => s.trim()).filter(Boolean);
    const query = (parts.length > 2 ? parts.slice(0, 2).join(", ") : value);
    const nq = norm(query);
    inp.focus();
    setNative(inp, "");
    const setter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
    for (let k = 1; k <= query.length; k++) {
      setter.call(inp, query.slice(0, k));
      inp.dispatchEvent(new Event("input", { bubbles: true }));
      inp.dispatchEvent(new KeyboardEvent("keyup", { key: query[k - 1], bubbles: true }));
      await sleep(35);
    }
    const readOpts = () => [...document.querySelectorAll("mat-option, .mat-mdc-option, .mat-mdc-autocomplete-panel [role=option]")].filter((o) => visible(o) && norm(o.textContent).length > 1);
    let all = [];
    const t0 = Date.now();
    while (Date.now() - t0 < 3500) { all = readOpts(); if (all.length) break; await sleep(200); }
    const real = all.filter((o) => !/don.?t see|can.?t find|no results|enter.*manually/i.test(o.textContent));
    const hit = pickOpt(real, nq) || (real.length ? real[0] : null);
    if (!hit) return true; // no suggestion → leave the typed query for the user to pick
    // Commit the EDQ suggestion. Common App renders the options in a CDK overlay that
    // intercepts coordinate/synthetic mouse clicks — but el.click() fires the option's
    // handler directly, which triggers the EDQ "format" fetch that fills line1/city/zip.
    try { hit.scrollIntoView({ block: "nearest" }); } catch (e) { /* noop */ }
    try { hit.click(); } catch (e) { /* noop */ }
    fireSeq(hit);
    try { inp.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true })); inp.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); } catch (e) { /* noop */ }
    // Wait for the parse to populate the manual sub-fields, THEN confirm the dialog — only
    // if it actually resolved, so we never save a half-typed/garbage address.
    let resolved = false;
    const r0 = Date.now();
    while (Date.now() - r0 < 4000) {
      const filled = [...document.querySelectorAll("input")].some((i) => { const w = i.closest && i.closest("ca-control-wrapper"); const l = w && w.querySelector(".control__label"); return l && /address line 1|^\s*city/i.test(l.textContent || "") && String(i.value || "").trim(); });
      if (filled) { resolved = true; break; }
      await sleep(250);
    }
    if (resolved) {
      const cont = [...document.querySelectorAll("button")].find((b) => visible(b) && !b.disabled && /continue,?\s*closes dialog/i.test((b.textContent || "").replace(/\s+/g, " ").trim()));
      if (cont) { try { cont.click(); } catch (e) { /* noop */ } await sleep(600); }
    }
    return true;
  }
  async function applyLookup(triggerEl, value) {
    const nv = norm(value);
    if (!nv) return false;
    // Inline typeahead (address) vs modal lookup (school): the address input advertises
    // itself with aria-autocomplete="list"; drive it inline instead of waiting for a dialog.
    const inl = triggerEl.matches && triggerEl.matches("input[aria-autocomplete=list]") ? triggerEl
      : (triggerEl.querySelector && triggerEl.querySelector("input[aria-autocomplete=list]"));
    if (inl) return applyInlineAutocomplete(inl, value);
    openControl(triggerEl);
    try { triggerEl.click(); } catch (e) { /* noop */ }
    // Wait for the dialog to render with its inputs.
    let root = null;
    const t0 = Date.now();
    while (Date.now() - t0 < 3500) {
      root = overlayRoot();
      if (root && [...root.querySelectorAll("input")].some(visible)) break;
      await sleep(150);
    }
    if (!root) return false;
    // Pick the NAME SEARCH box, not the "Search by" category selector. These
    // dialogs (Common App "Find school") have a category combobox first, then a
    // plain text field labelled "…Name". Prefer a plain text input whose nearby
    // label mentions name/school; explicitly skip role=combobox/listbox selectors.
    const inputs = [...root.querySelectorAll("input[type=text], input[type=search], input:not([type])")]
      .filter((i) => visible(i) && i.getAttribute("role") !== "combobox" && i.getAttribute("aria-autocomplete") !== "list" && i.getAttribute("aria-haspopup") !== "listbox");
    let box = inputs.find((i) => /name|school|college|search for/.test(nearLabel(i) + " " + norm(i.getAttribute("placeholder") || "")));
    if (!box) box = inputs[inputs.length - 1]; // fall back to the last plain input (name field follows the category)
    if (!box) { closeOverlay(); return false; }
    box.focus();
    setNative(box, value);
    box.dispatchEvent(new KeyboardEvent("keyup", { key: (value.slice(-1) || "a"), bubbles: true }));
    await sleep(700);
    // Wait for result rows. The mat-autocomplete panel renders in its OWN cdk-overlay,
    // a SIBLING of the dialog — so search the whole document, not just the dialog root
    // (scoping to the dialog finds zero options — the old bug that left College lookup blank).
    let opts = [];
    const r0 = Date.now();
    while (Date.now() - r0 < 3500) {
      opts = [...document.querySelectorAll("mat-option, .mat-mdc-option, [role=option], .cdk-overlay-pane li, [class*=result] button")]
        .filter((o) => visible(o) && norm(o.textContent).length > 2 && !/don.?t see|can.?t find|no results/i.test(o.textContent));
      if (opts.length) break;
      await sleep(200);
    }
    // STRICT match only — never pick the top/arbitrary result (that silently fills a WRONG
    // school). If the applicant's school isn't in the list, leave it for the user.
    const hit = pickOpt(opts, nv);
    if (!hit) { closeOverlay(); return false; }
    try { hit.scrollIntoView({ block: "nearest" }); } catch (e) { /* noop */ }
    // Select the matching result three ways (whichever the widget honours): (1) keyboard —
    // ArrowDown to the hit's index then Enter (mat-autocomplete commits the active option);
    // (2) el.click() (overlay-safe, fires the option handler directly); (3) fireSeq.
    const idx = opts.indexOf(hit);
    try { for (let k = 0; k <= idx; k++) { box.dispatchEvent(new KeyboardEvent("keydown", { key: "ArrowDown", bubbles: true })); await sleep(70); } box.dispatchEvent(new KeyboardEvent("keydown", { key: "Enter", bubbles: true })); } catch (e) { /* noop */ }
    await sleep(300);
    try { hit.click(); } catch (e) { /* noop */ }
    fireSeq(hit);
    await sleep(500);
    // Confirm the dialog. The button reads "Continue, Close dialog" (NOT the page's
    // "Continue to next section") — match that shape, or an Add/Select/Choose action. Poll,
    // since it enables only after the pick registers. el.click() (overlay-safe) to press it.
    let confirmed = false;
    const c0 = Date.now();
    while (Date.now() - c0 < 2500 && !confirmed) {
      const confirm = [...document.querySelectorAll("button")].find((b) => visible(b) && !b.disabled && /\b(continue|add|select|choose|save|done|confirm|apply)\b/i.test((b.textContent || "").replace(/\s+/g, " ").trim()) && !/next section|previous|cancel/i.test((b.textContent || "").replace(/\s+/g, " ").trim()));
      if (confirm) { try { confirm.click(); } catch (e) { /* noop */ } confirmed = true; }
      else await sleep(250);
    }
    await sleep(600);
    return !overlayRoot() || norm(document.body.textContent || "").includes(nv);
  }

  // Materialize extra repeat-group rows before filling. `clicks` = [{button,times}]
  // where button is the visible label of an "Add …" control. Re-find the button
  // each iteration (the DOM grows/re-renders) and wait for a new control to appear.
  async function addRows(clicks) {
    let added = 0;
    const countControls = () => document.querySelectorAll("input, select, textarea, [contenteditable]:not([contenteditable=false]), [role=combobox]").length;
    for (const c of clicks || []) {
      const want = norm(c.button || c.label || "");
      if (!want) continue;
      let times = Math.max(0, Math.min(9, parseInt(c.times, 10) || 0));
      for (let n = 0; n < times; n++) {
        const btn = [...document.querySelectorAll("button, a[role=button], [role=button]")].find((el) => {
          if (!visible(el) || el.disabled) return false;
          const t = norm(el.textContent || el.getAttribute("aria-label") || "");
          return t && (t === want || t.includes(want) || want.includes(t));
        });
        if (!btn) break;
        const before = countControls();
        try { btn.scrollIntoView({ block: "center" }); } catch (e) { /* noop */ }
        try { btn.click(); } catch (e) { /* noop */ }
        const t0 = Date.now();
        while (Date.now() - t0 < 2500) {
          await sleep(150);
          if (countControls() > before) break;
        }
        if (countControls() <= before) break; // click added nothing — stop hammering
        added++;
      }
    }
    return { added };
  }

  // Add-row controls on this screen ("Add activity", "Add another", "+") — passed
  // to the planner so it can decide how many extra rows the facts justify.
  function captureAddButtons() {
    const out = [];
    const seen = new Set();
    const re = /\badd\b|\banother\b|^\+$|add \+/i;
    const bad = /search|upload|attach|file|remove|delete|address|additional info/i;
    const schoolRe = /find (your )?(school|college|univers)|add (a |an )?(college|school|univers)|search (for )?(a )?(college|school|univers)/i;
    for (const el of document.querySelectorAll("button, a[role=button], [role=button]")) {
      if (!visible(el) || el.disabled) continue;
      const t = (el.textContent || el.getAttribute("aria-label") || "").replace(/\s+/g, " ").trim();
      if (!t || t.length > 40) continue;
      if (!re.test(t) || bad.test(t) || schoolRe.test(t)) continue; // school-find is a lookup, not a row-add
      if (el.closest("nav, [role=navigation], header, [class*=nav]")) continue;
      const key = norm(t);
      if (seen.has(key)) continue;
      seen.add(key);
      out.push({ label: t.slice(0, 40) });
    }
    return out;
  }

  // Reverse of background.js's arrayBufferToBase64 — FETCH_DOC crosses the
  // chrome.runtime message boundary as base64 (ArrayBuffer doesn't survive it).
  function base64ToBytes(b64) {
    const binary = atob(b64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
    return bytes;
  }

  async function attachDocs(documents) {
    let uploaded = 0;
    const files = [...document.querySelectorAll("input[type=file]")].filter(visible);
    for (const input of files) {
      const fl = norm(labelFor(input));
      const doc = (documents || []).find(
        (d) => d.downloadUrl && (fl.includes(norm(d.docType)) || norm(d.docType).split(" ").some((w) => w.length > 3 && fl.includes(w))),
      );
      if (!doc) continue;
      try {
        const r = await browser.runtime.sendMessage({ type: "FETCH_DOC", url: doc.downloadUrl });
        if (!r || !r.ok) continue;
        const file = new File([base64ToBytes(r.bytes)], doc.fileName || `${doc.docType}.pdf`, { type: doc.mime || r.mime || "application/octet-stream" });
        const dt = new DataTransfer();
        dt.items.add(file);
        input.files = dt.files;
        input.dispatchEvent(new Event("input", { bubbles: true }));
        input.dispatchEvent(new Event("change", { bubbles: true }));
        uploaded++;
      } catch (e) { /* skip */ }
    }
    return uploaded;
  }

  let comboDebug = []; // diagnostic: live dropdown overlay snapshots

  async function applyDecisions(decisions, documents, fields) {
    let filled = 0;
    comboDebug = [];
    const results = []; // [{ i, ok }] — per-decision outcome for the fill report
    const labelByI = {};
    for (const f of fields || []) labelByI[f.i] = norm(f.label || "");
    // Dedupe repeated dropdown rows: never pick the same option twice for an
    // identical label (e.g. 5× "Select language" → duplicate-language error).
    const usedByLabel = new Map();
    for (const d of decisions || []) {
      const slot = REG[d.i];
      const value = d.value;
      if (!slot || value == null || value === "") continue;
      const lab = labelByI[d.i] || "";
      const isSelect = slot.kind === "select";
      if (isSelect && lab) {
        const set = usedByLabel.get(lab);
        if (set && set.has(norm(value))) { results.push({ i: d.i, ok: false }); continue; }
      }
      // ok is set by RE-READING the live DOM after applying — so "filled" means the
      // value actually landed, not merely that we tried.
      let ok = false;
      try {
        if (slot.kind === "radio") {
          const label = pickOption(slot.options.map((o) => o.label), value);
          const hit = label && slot.options.find((o) => o.label === label);
          if (hit) { clickChoice(hit.el, hit.role); await sleep(30); ok = isChecked(hit.el, hit.role); }
        } else if (slot.kind === "checkbox") {
          const want = /^(true|yes|1|on|checked)$/i.test(value);
          if (isChecked(slot.el, slot.role) !== want) { clickChoice(slot.el, slot.role); await sleep(30); }
          ok = isChecked(slot.el, slot.role) === want;
        } else if (slot.kind === "select") {
          ok = slot.combo ? await applyCombo(slot.el, value) : setSelect(slot.el, value);
        } else if (slot.kind === "lookup") {
          ok = await applyLookup(slot.el, value);
        } else if (slot.kind === "richtext") {
          const el = slot.el;
          el.focus();
          // CKEditor 5 (Common App essays) ignores execCommand — drive its API. The
          // contenteditable .ck-content element carries a .ckeditorInstance.
          const cke = el.ckeditorInstance || (el.closest && el.closest("[class*=ck-editor]") && el.querySelector && el.querySelector(".ck-content")?.ckeditorInstance);
          if (cke && typeof cke.setData === "function") {
            const esc = String(value).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
            cke.setData("<p>" + esc + "</p>");
          } else {
            try { document.execCommand("selectAll", false, null); document.execCommand("insertText", false, value); }
            catch (e) { el.textContent = value; }
            if (!String(el.textContent || "").trim()) el.textContent = value;
          }
          el.dispatchEvent(new InputEvent("input", { bubbles: true }));
          el.dispatchEvent(new Event("change", { bubbles: true }));
          el.dispatchEvent(new Event("blur", { bubbles: true }));
          await sleep(20);
          ok = String(el.textContent || "").trim().length > 0;
        } else {
          setNative(slot.el, value); await sleep(20);
          ok = String(slot.el.value == null ? "" : slot.el.value).trim().length > 0;
        }
      } catch (e) { ok = false; }
      if (ok) {
        filled++;
        if (isSelect && lab) { const s = usedByLabel.get(lab) || new Set(); s.add(norm(value)); usedByLabel.set(lab, s); }
      }
      results.push({ i: d.i, ok });
    }
    const uploaded = await attachDocs(documents);
    return { filled, uploaded, results, debug: comboDebug.slice(0, 8) };
  }

  function sectionTitle() {
    const scope = document.querySelector("main,[role=main]") || document;
    const heads = [...scope.querySelectorAll("h1,h2")].map((h) => (h.textContent || "").replace(/\s+/g, " ").trim()).filter(Boolean);
    const good = heads.find((t) => !/^(my common application|common app|dashboard|need help)/i.test(t));
    return (good || heads[0] || "").slice(0, 120);
  }

  // ── operator DEEP-SCAN: read-only catalog of every field + real dropdown options ──
  // For each fixed dropdown it OPENS the control, reads the full option list, then
  // closes WITHOUT selecting. Async lookups (school/course search) are marked
  // kind:"lookup" and NOT enumerated. Never selects an option; never submits.
  // The scrollable options panel (CDK virtual-scroll recycles DOM, so long lists
  // only render their visible window — must scroll to materialize the rest).
  function scrollPanel() {
    const cands = document.querySelectorAll(
      ".cdk-virtual-scroll-viewport, .mat-mdc-select-panel, .mat-mdc-autocomplete-panel, .cdk-overlay-pane [role=listbox], .cdk-overlay-container [role=listbox], [role=listbox]",
    );
    for (const p of cands) if (visible(p) && p.scrollHeight > p.clientHeight + 4) return p;
    return null;
  }
  async function captureOptionsFor(el) {
    if (!el) return [];
    const ng = ngWrapOf(el); // scope reads to this control's own panel (no cross-leak)
    openControl(el);
    await sleep(250);
    let opts = await waitOptions(2000, ng);
    if (!opts.length && !ng) {
      for (const t of [el.querySelector && el.querySelector(".mat-mdc-select-trigger, .mat-select-trigger"), el]) {
        if (!t) continue;
        try { t.click(); } catch (e) { /* noop */ }
        await sleep(200);
        opts = await waitOptions(1500);
        if (opts.length) break;
      }
    }
    // Accumulate options across scroll steps (dedup by text) so virtual-scrolled
    // long lists are captured in full, not just the first rendered window.
    const seen = new Map(); // lowercased -> original text
    const collect = () => {
      for (const o of optionEls(ng)) {
        const raw = (o.textContent || "").replace(/\s+/g, " ").trim();
        if (raw && !seen.has(raw.toLowerCase())) seen.set(raw.toLowerCase(), raw);
      }
    };
    collect();
    const panel = scrollPanel();
    if (panel) {
      let last = -1, guard = 0;
      while (seen.size !== last && guard++ < 60) {
        last = seen.size;
        panel.scrollTop = panel.scrollTop + Math.max(120, panel.clientHeight * 0.85);
        await sleep(130);
        collect();
        if (panel.scrollTop + panel.clientHeight >= panel.scrollHeight - 2) { await sleep(130); collect(); break; }
      }
    }
    // Close WITHOUT selecting anything.
    try { ((el.querySelector && el.querySelector("input")) || el).dispatchEvent(new KeyboardEvent("keydown", { key: "Escape", bubbles: true })); document.body.click(); } catch (e) { /* noop */ }
    await sleep(120);
    return [...seen.values()];
  }

  async function deepScanScreen() {
    const fields = captureFields();
    const section = sectionTitle();
    const out = [];
    let order = 0;
    for (const f of fields) {
      const slot = REG[f.i];
      let options = f.options || [];
      let kind = f.kind;
      if (f.kind === "select" && slot && slot.combo && !options.length) {
        const lbl = norm(f.label);
        if (/find (your )?(school|college|univers)|search|look ?up/.test(lbl)) {
          kind = "lookup"; // async DB — not enumerable
        } else {
          options = await captureOptionsFor(slot.el); // fixed dropdown → read real options
        }
      }
      out.push({
        normLabel: norm(f.label), label: (f.label || "").slice(0, 160), kind,
        options: (options || []).slice(0, 200),
        required: /\*|required/i.test(f.label || "") || undefined,
        order: order++, html: f.html,
      });
    }
    return { section, title: section, fields: out };
  }

  // ── deterministic fallback (backend unreachable) ────────────────────────────
  function score(step, f) {
    const fname = norm(f.name), flabel = norm(f.label);
    for (const n of step.match?.name || []) { const nn = norm(n); if (nn && fname === nn) return 100; }
    const labels = [norm(step.label), ...((step.match?.labels || []).map(norm))].filter(Boolean);
    for (const l of labels) if (flabel && flabel === l) return 80;
    for (const l of labels) if (flabel && l.length > 3 && (flabel.includes(l) || l.includes(flabel))) return 60;
    return 0;
  }

  async function deterministicFill(steps, documents) {
    const fields = captureFields();
    const used = new Set();
    let filled = 0;
    const sorted = [...steps].sort((a, b) => (b.required ? 1 : 0) - (a.required ? 1 : 0));
    for (const step of sorted) {
      if (!step.value) continue;
      let best = null, bestScore = 55;
      for (const f of fields) {
        if (used.has(f.i) || f.kind === "radio" || f.kind === "checkbox") continue;
        const sc = score(step, f);
        if (sc > bestScore) { bestScore = sc; best = f; }
      }
      if (!best) continue;
      used.add(best.i);
      const slot = REG[best.i];
      try {
        if (slot.kind === "select") { if (setSelect(slot.el, step.value)) filled++; }
        else { setNative(slot.el, step.value); filled++; }
      } catch (e) { /* skip */ }
    }
    const uploaded = await attachDocs(documents);
    return { filled, uploaded };
  }

  // ── navigation / advance ────────────────────────────────────────────────────
  const isCommonApp = () => /(^|\.)commonapp\.org$/i.test(location.hostname);
  const SECTIONS = ["Profile", "Family", "Education", "Testing", "Activities", "Writing"];
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

  function pageSig() {
    return location.href + "|" + document.querySelectorAll("input,select,textarea").length + "|" + norm((document.querySelector("h1,h2")?.textContent) || "").slice(0, 40);
  }
  async function waitForChange(before, timeout) {
    const t0 = Date.now();
    while (Date.now() - t0 < timeout) {
      await sleep(250);
      if (pageSig() !== before) { await sleep(600); return true; }
    }
    return false;
  }

  function findContinue() {
    const cands = [...document.querySelectorAll("button, input[type=submit], input[type=button], a[role=button]")];
    const good = /\b(continue|save and continue|save & continue|save and next|next|proceed)\b/i;
    const bad = /\b(submit|sign ?out|log ?out|logout|cancel|back|previous|prev|delete|remove|search|add another)\b/i;
    let best = null;
    for (const el of cands) {
      if (!visible(el) || el.disabled) continue;
      const t = norm(el.textContent || el.value || "");
      if (!t || t.length > 40 || bad.test(t) || !good.test(t)) continue;
      const w = /continue/.test(t) ? 3 : /next|proceed/.test(t) ? 2 : 1;
      if (!best || w > best.w) best = { el, w };
    }
    return best ? best.el : null;
  }

  function sectionLinks() {
    const map = {};
    for (const a of document.querySelectorAll("a, button")) {
      if (!visible(a)) continue;
      const t = (a.textContent || "").trim();
      const hit = SECTIONS.find((s) => t === s || norm(t) === norm(s));
      if (hit && !map[hit]) map[hit] = a;
    }
    return map;
  }

  let hlTimer = null;
  function highlight(el, text) {
    if (!el) return;
    try {
      el.scrollIntoView({ behavior: "smooth", block: "center" });
      const prev = el.style.outline, prevOff = el.style.outlineOffset;
      el.style.outline = "3px solid #b3272c";
      el.style.outlineOffset = "3px";
      const tip = document.createElement("div");
      tip.textContent = text || "Click here to continue →";
      Object.assign(tip.style, {
        position: "fixed", zIndex: 2147483647, background: "#b3272c", color: "#fff",
        font: "700 12px/1.3 system-ui, sans-serif", padding: "6px 10px", borderRadius: "8px",
        border: "2px solid #1c1c19", boxShadow: "3px 3px 0 0 #1c1c19", pointerEvents: "none", maxWidth: "240px",
      });
      const r = el.getBoundingClientRect();
      tip.style.top = Math.max(8, r.top - 34) + "px";
      tip.style.left = Math.max(8, Math.min(window.innerWidth - 250, r.left)) + "px";
      document.documentElement.appendChild(tip);
      clearTimeout(hlTimer);
      hlTimer = setTimeout(() => { el.style.outline = prev; el.style.outlineOffset = prevOff; tip.remove(); }, 6000);
    } catch (e) { /* ignore */ }
  }

  async function clickContinue() {
    const c = findContinue();
    if (!c) return { moved: false, none: true };
    const before = pageSig();
    c.click();
    const moved = await waitForChange(before, 9000);
    return { moved };
  }
  async function gotoSection(name) {
    const a = sectionLinks()[name];
    if (!a) return { ok: false };
    const before = pageSig();
    a.click();
    await waitForChange(before, 9000);
    return { ok: true };
  }

  // ── MAP-DRIVEN FILL ─────────────────────────────────────────────────────────
  // The authoritative Common App map (from Cowork) tells us, per SECTION, which
  // concept each labelled field holds. We match the map's section to THIS screen,
  // resolve each field's value from the answer store, and reuse applyDecisions —
  // so parent1 vs parent2 vs applicant never collide (distinct concepts per section)
  // and all the widget handling (combobox scroll, radio, checkbox, lookup) is reused.
  const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
  function formatDate(value, fmt) {
    const full = String(value).match(/^(\d{4})-(\d{2})-(\d{2})$/); // YYYY-MM-DD
    const ym = String(value).match(/^(\d{4})-(\d{2})$/);            // YYYY-MM (SAT/entry/grad dates)
    const m = full || ym;
    if (!m) return value; // already a display string / unknown shape → leave as-is
    const mon = MONTHS[parseInt(m[2], 10) - 1] || "";
    const f = (fmt || "").toLowerCase();
    // A day-bearing value + a "…day…" format (Date of birth) → "August 1, 2002".
    // Everything else (month-year) → "August 2002". A YYYY-MM value has no day to show.
    if (full && (!fmt || /\bday\b|d,|dd?\b/.test(f))) return `${mon} ${parseInt(full[3], 10)}, ${m[1]}`;
    return `${mon} ${m[1]}`;
  }

  // ── REPEAT GROUPS (activities x10, languages, honors, courses, siblings, …) ──
  // The answer store keys repeat rows as `${group}_${i}_${suffix}` (activity_1_type,
  // activity_2_type, …). Map item-fields carry `repeat:{group,suffix,max}`. For each
  // group we materialise N rows (set the count control, or click "Add"), then fill row
  // i from the indexed answer. Per-group materialisation config is Common-App-specific.
  const REPEAT_GROUPS = {
    language:         { count: "number of languages you are proficient" },
    sibling:          { count: "specify number of siblings you have" },
    other_school:     { count: "attended any secondary" },
    college_attended: { count: "ever taken coursework at a college" },
    community_org:    { count: "number of community programs" },
    honor:            { gate: "do you wish to report any honors", add: "add" },
    activity:         { gate: "do you wish to report any activities", add: "add" },
    course:           { count: "list all courses you are taking", extra: [{ match: "course scheduling system", value: "Semester" }] },
  };
  // lowercased label with digits and a lone "n" removed, so "Course 1 subject",
  // "Course 2 subject" and the map's "Course N subject" all collapse to "course subject".
  function coreLabel(x) { return norm(x).replace(/\b\d+\b/g, " ").replace(/\bn\b/g, " ").replace(/\s+/g, " ").trim(); }
  function repeatCount(group, answers, max) {
    let n = 0; const re = new RegExp("^" + group + "_(\\d+)_");
    for (const k in (answers || {})) { const m = k.match(re); if (m) n = Math.max(n, parseInt(m[1], 10)); }
    return Math.min(n, max || 99);
  }
  async function setCountControl(labelMatch, valueStr) {
    const want = norm(labelMatch);
    const f = captureFields().find((x) => (x.kind === "select" || x.kind === "radio") && norm(x.label).includes(want));
    if (!f) return false;
    const slot = REG[f.i];
    if (slot.kind === "radio") {
      // The count/gate radios are worded ("None", "No, I have not …", "3 or more"), so a
      // bare "0"/"No" won't equal a label — resolve via the same synonym matcher used for
      // options, then fall back to an exact/substring hit.
      const labels = slot.options.map((o) => o.label);
      const want = pickOption(labels, String(valueStr)) || labels.find((l) => norm(l) === norm(valueStr));
      const opt = want && slot.options.find((o) => o.label === want);
      if (opt) { clickChoice(opt.el, opt.role); await sleep(350); return true; }
      return false;
    }
    return await applyCombo(slot.el, String(valueStr));
  }
  // A group with no answered rows still has a "how many / have you …?" control that must
  // read "none" for the section to complete. Set the gate to No, or the count to zero.
  async function clearRepeatGroup(group, cfg) {
    try {
      if (cfg.gate) { await setCountControl(cfg.gate, "No"); return; }
      if (cfg.count) { for (const v of ["0", "None", "No", "I have not"]) { if (await setCountControl(cfg.count, v)) return; } }
    } catch (e) { /* best-effort */ }
  }
  async function materializeGroup(group, cfg, n, existing) {
    if (cfg.gate) { // Yes/No that reveals the first row
      const g = captureFields().find((x) => x.kind === "radio" && norm(x.label).includes(norm(cfg.gate)));
      if (g) { const y = REG[g.i].options.find((o) => /^yes$/i.test(o.label)); if (y) { clickChoice(y.el, y.role); await sleep(450); } }
    }
    for (const ex of cfg.extra || []) { await setCountControl(ex.match, ex.value); await sleep(200); }
    if (cfg.count) { await setCountControl(cfg.count, n); await sleep(550); }
    else if (cfg.add) { // click "Add …" until N rows exist (row 1 present after the gate)
      // Start from the rows ALREADY present so a second fill pass doesn't keep piling on
      // empty rows (the "Honors 4/5 title required" bug). Only add the deficit up to n.
      const cnt = () => document.querySelectorAll("input,select,textarea,[contenteditable]:not([contenteditable=false]),ng-select,[role=combobox]").length;
      for (let k = Math.max(existing || 1, 1); k < n; k++) {
        const before = cnt();
        const btn = [...document.querySelectorAll("button,a[role=button],[role=button]")].find((b) => visible(b) && !b.disabled && norm(b.textContent).length < 40 && norm(b.textContent).includes(norm(cfg.add)) && !/search|remove|delete|continue/.test(norm(b.textContent)));
        if (!btn) break;
        try { btn.scrollIntoView({ block: "center" }); btn.click(); } catch (e) { /* noop */ }
        const t0 = Date.now(); while (Date.now() - t0 < 2500) { await sleep(160); if (cnt() > before) break; }
      }
    }
    await sleep(300);
  }
  // Trim a repeat group down to `targetN` rows by clicking each row's "Remove …" control
  // and confirming the modal. IMPORTANT: use el.click() (the DOM method) — Common App's
  // overlay intercepts coordinate clicks, but el.click() fires the handler directly (this is
  // why a plain dispatched/synthetic mouse-click on these modal buttons does nothing).
  async function removeExtraRows(targetN, coreOf) {
    for (let guard = 0; guard < 15; guard++) {
      const rowCount = captureFields().filter((c) => coreLabel(c.label) === coreOf).length;
      if (rowCount <= targetN) break;
      const btns = [...document.querySelectorAll("button,[role=button]")].filter((b) => visible(b) && /^remove\s+\S/i.test((b.getAttribute("aria-label") || "").trim()) && !/\ball\b|permanent home address|mailing address/i.test(b.getAttribute("aria-label") || ""));
      if (!btns.length) break;
      btns.sort((a, b) => (parseInt((b.getAttribute("aria-label").match(/\d+/) || [0])[0], 10) - parseInt((a.getAttribute("aria-label").match(/\d+/) || [0])[0], 10)));
      try { btns[0].scrollIntoView({ block: "center" }); btns[0].click(); } catch (e) { /* noop */ }
      await sleep(1000);
      const conf = document.querySelector('button[aria-label="Remove, Closes dialog"], button#alert_rc_r')
        || [...document.querySelectorAll(".mat-mdc-dialog-container button, mat-dialog-container button, [role=dialog] button, [role=alertdialog] button")].find((x) => visible(x) && /^(remove|delete|yes|confirm)$/i.test((x.textContent || "").replace(/\s+/g, " ").trim()));
      if (conf) { try { conf.click(); } catch (e) { /* noop */ } }
      await sleep(1400);
    }
  }
  async function fillRepeats(mapFields, answers) {
    const repFields = (mapFields || []).filter((f) => f.repeat && f.repeat.group && f.repeat.suffix);
    const groups = [...new Set(repFields.map((f) => f.repeat.group))];
    let filled = 0, rows = 0;
    for (const group of groups) {
      const cfg = REPEAT_GROUPS[group] || {};
      const gf = repFields.filter((f) => f.repeat.group === group);
      const max = Math.max.apply(null, gf.map((f) => f.repeat.max || 10));
      const n = repeatCount(group, answers, max);
      if (n < 1) { await clearRepeatGroup(group, cfg); continue; } // no rows → set "none/No" so the section still completes
      // A group of searchable selects (Activities: 10 "Activity type" ng-selects) loads its
      // option lists ~6-7s after the page renders. If we OPEN one before that, it caches an
      // empty panel and never recovers — so wait once, up front, before touching them.
      if (!fillRepeats._settledHref && gf.some((f) => f.kind === "select" || f.kind === "lookup")) {
        fillRepeats._settledHref = location.href;
        await sleep(6000);
      }
      // How many rows are ALREADY present? (count occurrences of the group's first
      // repeated control) — so materializeGroup only adds the deficit, never re-adds.
      const cap0 = captureFields();
      const f0 = gf[0], f0core = coreLabel((f0.find && f0.find.labelText) || f0.label);
      const existing = cap0.filter((c) => coreLabel(c.label) === f0core).length;
      await materializeGroup(group, cfg, n, existing);
      // Too many rows already present (e.g. an earlier over-fill left 5 Honors rows for 3
      // honors → rows 4/5 stay required-empty and the section can't complete). Trim the
      // excess back to n so every remaining row gets data.
      if (existing > n) { await removeExtraRows(n, f0core); }
      const cap = captureFields(); // REG now reflects the materialised rows
      // For each suffix, the per-row controls appear (mostly) N times in DOM order.
      // Match a captured control to a map field by its (digit-stripped) label. Tolerant of
      // small wording drift — the live form inserts ", etc." into the activity-description
      // label, so exact equality misses ALL 10 textareas (occ=0 → nothing fills). Accept an
      // exact match, a substring either way, or a shared 20+ char prefix.
      const labelMatch = (a, b) => { const x = coreLabel(a), y = coreLabel(b); if (!x || !y) return false; if (x === y || x.includes(y) || y.includes(x)) return true; const p = Math.min(x.length, y.length, 30); return p >= 20 && x.slice(0, p) === y.slice(0, p); };
      const occBy = {};
      for (const f of gf) { const ml = (f.find && f.find.labelText) || f.label; occBy[f.repeat.suffix] = cap.filter((c) => labelMatch(c.label, ml)); }
      // Map row-index → control per suffix. Normal fields appear once per row, so
      // control[i] = occurrence[i-1]. CONDITIONAL fields (e.g. Sport/team, which only
      // renders for Athletics rows) have fewer occurrences than rows — align those to the
      // rows that actually carry an answer, in order, so they don't fall off the index.
      // The sequential re-alignment is ONLY for genuinely conditional fields (f.conditional,
      // e.g. Sport/team). A normal field (a description CKEditor) that is merely slow to mount
      // must keep row-index mapping — a later pass fills the rows whose control wasn't ready
      // yet; sequentially packing it would mis-assign row 5's text into row 1.
      const ctrlFor = {};
      for (const f of gf) {
        const suf = f.repeat.suffix, occ = occBy[suf] || [], m = {};
        if (f.conditional && occ.length < n) { let p = 0; for (let i = 1; i <= n && p < occ.length; i++) { const v = answers[group + "_" + i + "_" + suf]; if (v != null && String(v).trim() !== "") m[i] = occ[p++]; } }
        else { for (let i = 1; i <= n; i++) m[i] = occ[i - 1]; }
        ctrlFor[suf] = m;
      }
      for (let i = 1; i <= n; i++) {
        const decs = [];
        for (const f of gf) {
          let val = answers[group + "_" + i + "_" + f.repeat.suffix];
          if (val == null || String(val) === "") continue;
          if ((f.kind === "select" || f.kind === "radio") && f.options && f.options.length) val = pickOption(f.options, val) || val;
          if (f.kind === "checkbox" && f.options && f.options.length) {
            // checkbox group inside a row: check each matching option in THIS row's control set
            const wants = String(val).split(/[,;]+/).map((w) => w.trim()).filter(Boolean);
            const cf = (occBy[f.repeat.suffix] || [])[i - 1];
            void cf; // per-row checkbox handled below via label match within the row card
            for (const w of wants) {
              const optLbl = pickOption(f.options, w) || w;
              const box = cap.find((c) => c.kind === "checkbox" && norm(c.label) === norm(optLbl) && !decs.some((d) => d.i === c.i));
              if (box) decs.push({ i: box.i, value: "true" });
            }
            continue;
          }
          if (f.kind === "date") val = formatDate(val, f.format);
          const cf = (ctrlFor[f.repeat.suffix] || {})[i];
          if (cf) decs.push({ i: cf.i, value: String(val) });
        }
        if (!decs.length) continue;
        const rr = await applyDecisions(decs, [], cap); // one row per call → no label-dedupe clash
        filled += rr.filled; rows++;
      }
    }
    return { filled, rows };
  }

  async function fillFromMap(map, answers, documents) {
    // Heavy dropdown sections (Activities renders ~20 searchable ng-selects) load their
    // option lists ~6-7s AFTER the page renders. Reading/opening a select before then
    // poisons its panel (it caches empty and never recovers), so idle FIRST — before the
    // first captureFields — exactly once per URL, mirroring the wait that makes it work.
    if (fillFromMap._idledHref !== location.href && document.querySelectorAll("ng-select").length >= 8) {
      fillFromMap._idledHref = location.href;
      await sleep(6000); // let the option lists hydrate before touching the selects
    }
    const secTitle = sectionTitle();
    const href = location.href;
    const sections = (map && map.sections) || [];
    // The permanent-address widget is a single typeahead (concept "address_lookup"), but
    // the store keeps the address in parts. Compose a full-address string so the lookup
    // has something to match. (Real addresses resolve; a placeholder one simply won't.)
    if (answers && answers.address_lookup == null) {
      // Lean single-line (street, city, state, zip) — matches the typeahead's suggestion
      // format; apt/line2/country dilute the token match and are re-derived by the widget.
      const a = answers, line = [a.address_street, a.address_city, a.address_state, a.address_postal].filter((x) => x != null && String(x).trim() !== "");
      if (line.length >= 2) answers = Object.assign({}, answers, { address_lookup: line.join(", ") });
    }
    let captured = captureFields();
    // Identify THIS screen's section: exact title → url fragment → best label overlap
    // (robust even if the captured title drifts or the URL is session-specific).
    const overlap = () => {
      const capLabels = new Set(captured.map((f) => norm(f.label)));
      let best = null, bestScore = 0;
      for (const s of sections) { let sc = 0; for (const f of s.fields || []) if (capLabels.has(norm((f.find && f.find.labelText) || f.label))) sc++; if (sc > bestScore) { bestScore = sc; best = s; } }
      return bestScore >= 2 ? best : null;
    };
    let mapSection = sections.find((s) => s.title && norm(s.title) === norm(secTitle))
      || sections.find((s) => s.urlIncludes && href.includes(s.urlIncludes))
      || overlap();
    // Heavy sections (the Address autocomplete, the CKEditor essays, and any gate that
    // reveals more on answer) mount their controls ~2-3s AFTER navigation. If we matched
    // a section that should have several fields but the DOM is still sparse, let it settle
    // once and re-capture so a single fill pass doesn't run against an empty screen.
    if (mapSection && (mapSection.fields || []).length >= 4 && captured.length < 3) {
      // A saved section collapses to a summary with a "Change …" / "Edit answer" button;
      // click it to re-open the form before filling.
      const rev = [...document.querySelectorAll("button, a[role=button]")].find((b) => visible(b) && !b.disabled && /^(change|edit)\b/i.test((b.textContent || "").replace(/\s+/g, " ").trim()) && (b.textContent || "").length < 60);
      if (rev) { try { rev.scrollIntoView({ block: "center" }); rev.click(); } catch (e) { /* noop */ } await sleep(900); }
      await sleep(1500); captured = captureFields();
      mapSection = sections.find((s) => s.title && norm(s.title) === norm(secTitle))
        || sections.find((s) => s.urlIncludes && href.includes(s.urlIncludes))
        || overlap();
    }
    // Dropdown-heavy sections (Activities = 10 searchable "Activity type" ng-selects) need
    // their ng-select OPTION data to finish hydrating; otherwise applyNgSelect opens a
    // control with an empty panel, falls back to type-filtering, and the pick never sticks.
    // Give the page a moment before the first pass when the matched section is select-heavy.
    if (mapSection && fillFromMap._settledHref !== href) {
      // Count the searchable dropdowns ACTUALLY ON SCREEN, not just distinct map fields —
      // Activities has ONE map field "activity.type" but renders 10 ng-selects, whose EDQ-
      // style option data hydrates ~2s late. Settling only on map-field count missed them
      // (types stayed empty). ≥5 on-screen selects ⇒ let the panel data hydrate first.
      const selOnScreen = captured.filter((f) => f.kind === "select").length;
      if (selOnScreen >= 5) { fillFromMap._settledHref = href; await sleep(5000); captured = captureFields(); }
    }
    const mapFields = mapSection ? (mapSection.fields || []) : sections.flatMap((s) => s.fields || []);
    // Index captured fields by label -> ARRAY (one label can front several controls:
    // the phone widget shows "Preferred phone number" for BOTH a dial-code <ng-select>
    // and the tel <input>). We disambiguate by kind so each map concept lands on the
    // right control instead of both fighting over the first match.
    const byLabel = new Map();
    for (const f of captured) { const k = norm(f.label); if (!byLabel.has(k)) byLabel.set(k, []); byLabel.get(k).push(f); }
    const usedI = new Set(); // never bind two concepts to the same captured control
    const candidatesFor = (want, exact) => {
      const w = norm(want);
      if (!w) return [];
      if (byLabel.has(w)) return byLabel.get(w);
      if (exact) return [];
      const out = [];
      for (const [k, arr] of byLabel) if (k && (k.includes(w) || w.includes(k))) out.push(...arr);
      return out;
    };
    // Acceptable captured kinds for a given MAP kind, best first.
    const prefKinds = (mk) => ({
      select: ["select"], radio: ["radio"], checkbox: ["checkbox"],
      tel: ["number", "text", "textarea"], number: ["number", "text"],
      date: ["date", "text"], richtext: ["richtext", "textarea", "text"],
      lookup: ["lookup", "select"],
    }[mk] || ["text", "textarea", "number", "date", "select"]);
    const pickField = (want, mapKind, exact) => {
      const cands = candidatesFor(want, exact).filter((f) => !usedI.has(f.i));
      if (!cands.length) return null;
      for (const k of prefKinds(mapKind)) { const hit = cands.find((f) => f.kind === k); if (hit) return hit; }
      // Last-resort fallback ONLY for free-text map kinds. A structured field (select /
      // lookup / radio / checkbox) must NOT spill into an incompatible control — e.g. the
      // country-code "Preferred phone number" SELECT and the phone-number TEL share a label;
      // falling back would dump "+1 United States" into the tel (mask → "1").
      if (["text", "textarea", "number", "tel", "date", "richtext"].includes(mapKind)) return cands[0];
      return null;
    };
    const hasAns = (c) => answers && answers[c] != null && String(answers[c]).trim() !== "";
    const decisions = [];
    for (let mi = 0; mi < mapFields.length; mi++) {
      const mf = mapFields[mi];
      let val = answers ? answers[mf.concept] : undefined;
      // Yes/No GATE with no explicit answer: default "No", BUT flip to "Yes" when the
      // user actually has data for a field this gate reveals — otherwise that data
      // would never surface. Look ahead over the following conditional fields (until
      // the next gate) and check whether any of their concepts is answered.
      if (mf.gate && (val == null || val === "")) {
        let reveal = false;
        for (let j = mi + 1; j < mapFields.length; j++) {
          const nf = mapFields[j];
          if (nf.gate) break;
          if (nf.conditional && hasAns(nf.concept)) { reveal = true; break; }
        }
        val = reveal ? "Yes" : "No";
      }
      if (val == null || String(val) === "") continue;
      // CHECKBOX GROUP: the concept holds the chosen value(s); check the matching option
      // checkbox(es) by their exact label (the live form has one checkbox per option).
      if (mf.kind === "checkbox" && mf.options && mf.options.length) {
        const wants = mf.multiSelect ? String(val).split(/[,;]+/).map((s) => s.trim()).filter(Boolean) : [String(val)];
        for (const w of wants) {
          // Normalise the stored value to the EXACT live option label before matching.
          const optLabel = pickOption(mf.options, w) || w;
          const cf = pickField(optLabel, "checkbox", true);
          if (cf && cf.kind === "checkbox") { decisions.push({ i: cf.i, value: "true" }); usedI.add(cf.i); }
        }
        continue;
      }
      // For choosers, translate a stored synonym to the map's EXACT option string so
      // the live-DOM option match is unambiguous (e.g. "USA" -> "United States of America").
      if ((mf.kind === "select" || mf.kind === "radio") && mf.options && mf.options.length) {
        val = pickOption(mf.options, val) || val;
      }
      if (mf.kind === "date") val = formatDate(val, mf.format);
      const cf = pickField((mf.find && mf.find.labelText) || mf.label, mf.kind, false);
      if (cf) { decisions.push({ i: cf.i, value: String(val) }); usedI.add(cf.i); }
    }
    const res = await applyDecisions(decisions, documents, captured);
    let repFilled = 0, repRows = 0;
    try { const rp = await fillRepeats(mapFields, answers); repFilled = rp.filled; repRows = rp.rows; } catch (e) { /* repeats best-effort */ }
    return { filled: res.filled + repFilled, uploaded: res.uploaded, matched: decisions.length, repeatRows: repRows, section: mapSection ? mapSection.title : "" };
  }

  // ── COMMON APP API FILL (the deterministic "closer") ─────────────────────────
  // The DOM fill can't beat three widgets: the EDQ address autocomplete, the parent
  // college mat-autocomplete, and the late-hydrating activity choice controls. But
  // Common App persists EVERY answer through one JSON endpoint —
  //   POST api25.commonapp.org/answer/v2  {"Answers":[{questionId,response,memberQuestionTemplateId}]}
  // — and a content-script fetch with host_permissions bypasses the page's CORS. So we
  // read the section schema + current answers, map the user's stored values onto the
  // remaining required questions, POST them, and verify greenness against the SAME
  // status feed the left-nav ticks use (/answer/status/screens/common). No widget racing.
  const CA_API = "https://api25.commonapp.org";
  // Public static key shipped in the Common App client bundle (same for every applicant).
  const CA_API_KEY = "tYFvpgKw3GaxrwoztllAc2j5bekLdMF25aayCxwx";
  let CA_GEO = null; // { states:{name|code -> {value,code}}, countries:{...} } — bundled

  function caIdToken() {
    try { for (let i = 0; i < localStorage.length; i++) { const k = localStorage.key(i); if (/CognitoIdentityServiceProvider\..*\.idToken$/.test(k)) return localStorage.getItem(k); } } catch (e) { /* no ls */ }
    return null;
  }
  function caUuid() { return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (c) => { const r = Math.floor(Math.random() * 16); const v = c === "x" ? r : (r & 0x3) | 0x8; return v.toString(16); }); }
  function caHeaders(token, withBody) {
    const h = { "Authorization": token, "x-api-key": CA_API_KEY, "x-ca-correlationid": caUuid(), "Accept": "application/json, text/plain, */*" };
    if (withBody) h["Content-Type"] = "application/json";
    return h;
  }
  async function caGet(token, path) {
    const r = await fetch(CA_API + path, { headers: caHeaders(token, false) });
    if (!r.ok) throw new Error("GET " + path + " -> " + r.status);
    return r.json();
  }
  async function caPost(token, answers) {
    const r = await fetch(CA_API + "/answer/v2", { method: "POST", headers: caHeaders(token, true), body: JSON.stringify({ Answers: answers }) });
    return r.json().catch(() => ({}));
  }
  async function caLoadGeo() {
    if (CA_GEO) return CA_GEO;
    try { const r = await fetch(browser.runtime.getURL("caGeo.json")); if (r.ok) CA_GEO = await r.json(); } catch (e) { /* injected/no runtime */ }
    return CA_GEO || { states: {}, countries: {} };
  }
  const caClean = (s) => (s == null ? "" : String(s)).replace(/<[^>]+>/g, " ").replace(/\s+/g, " ").trim();

  // Build a section-title -> [fields] index from the Cowork map, plus a flat list.
  function caIndexMap(map) {
    const bySection = {}; const flat = [];
    for (const sec of (map && map.sections) || []) {
      const key = norm(sec.title || "");
      bySection[key] = sec.fields || [];
      for (const f of sec.fields || []) flat.push({ sec: key, field: f });
    }
    return { bySection, flat };
  }
  // Find the map field for an API question: prefer a field in a section whose title
  // matches the API section name, else fall back to a unique label match anywhere.
  function caMatchField(idx, apiSection, apiLabel) {
    const secN = norm(apiSection); const labN = norm(apiLabel);
    const labMatch = (fl) => { const a = norm(fl.label || ""); if (!a || !labN) return false; return a === labN || a.includes(labN) || labN.includes(a) || (a.length >= 18 && labN.slice(0, 18) === a.slice(0, 18)); };
    // section-scoped
    for (const secKey of Object.keys(idx.bySection)) {
      if (!(secKey.includes(secN) || secN.includes(secKey))) continue;
      const hit = idx.bySection[secKey].find(labMatch);
      if (hit) return hit;
    }
    // global unique label
    const hits = idx.flat.filter((x) => labMatch(x.field));
    return hits.length === 1 ? hits[0].field : null;
  }
  // Map a human option label to its server choice value = its INDEX in the map's
  // ordered options list (verified: grades ["9".."12","PG"] -> "0".."4"; timing -> 0..2).
  function caOptionIndex(field, label) {
    const opts = (field && field.options) || []; const t = norm(label);
    if (!t) return null;
    let i = opts.findIndex((o) => norm(o) === t);
    if (i < 0) i = opts.findIndex((o) => { const n = norm(o); return n && (n.includes(t) || t.includes(n)); });
    return i >= 0 ? String(i) : null;
  }
  function caBuildAddress(answers, geo) {
    const st = geo.states[norm(answers.address_state)] || { value: "0", code: "" };
    const cn = geo.countries[norm(answers.address_country)] || { value: "0", code: "USA" };
    return { address1: answers.address_street || "", address2: answers.address_line2 || null, address3: null, city: answers.address_city || "", state: st.value, county: null, zip: answers.address_postal || "", countryCode: cn.value, stateValue: st.code, countryValue: cn.code, countryAbbreviation: null, geoLocation: null };
  }
  // College lookup (type 13) REQUIRES a valid CEEB code. Accept either a ready object
  // in the answer store, or a "<concept>_ceeb" sibling; otherwise leave it for the user.
  function caBuildCollege(concept, answers, geo) {
    const v = answers[concept];
    if (v && typeof v === "object" && v.ceebCode) return v;
    const ceeb = answers[concept + "_ceeb"];
    if (!ceeb) return null;
    const st = geo.states[norm(answers[concept + "_state"])];
    const addr = st ? { address1: answers[concept + "_street"] || "", address2: null, address3: null, city: answers[concept + "_city"] || "", state: st.value, county: null, zip: answers[concept + "_zip"] || "", countryCode: "0", stateValue: st.code, countryValue: "USA", countryAbbreviation: null, geoLocation: null } : null;
    return { ceebCode: String(ceeb), name: typeof v === "string" ? v : (answers[concept + "_name"] || ""), schoolTypeCode: null, address: addr };
  }

  // Resolve the response for ONE incomplete question from the user's answer store.
  // `rowN` is the 1-based occurrence for repeat-group concepts (activity_2_grade_levels…).
  function caResolve(q, field, answers, geo, rowN) {
    const concept = field && field.concept;
    // repeat concepts use a dotted key ("activity.grade_levels") -> "activity_<n>_grade_levels"
    let key = concept;
    let raw;
    if (concept && concept.includes(".")) {
      const parts = concept.split(".");
      key = parts[0] + "_" + rowN + "_" + parts.slice(1).join("_");
    }
    raw = concept ? answers[key] : undefined;
    switch (q.questionType) {
      case 12: return caBuildAddress(answers, geo);
      case 13: case 14: return concept ? caBuildCollege(key.replace(/_ceeb$/, ""), answers, geo) : null;
      case 6: return raw != null && String(raw).trim() ? String(raw) : null; // text/richtext
      case 8: { // multi-checkbox: comma-joined option indices
        if (raw == null || raw === "") return null;
        const idxs = String(raw).split(",").map((p) => caOptionIndex(field, p.trim())).filter((x) => x != null);
        return idxs.length ? idxs.join(",") : null;
      }
      case 7: case 9: { // single choice / yes-no
        if (raw == null || raw === "") return null;
        return caOptionIndex(field, raw);
      }
      default: return null;
    }
  }

  async function apiFill(map, answers) {
    const token = caIdToken();
    if (!token) return { noAuth: true };
    if (!/commonapp\.org$/i.test(location.hostname) && !/commonapp\.org$/i.test(location.host)) return { notCommonApp: true };
    const geo = await caLoadGeo();
    const idx = caIndexMap(map);
    answers = answers || {};

    let status;
    try { status = await caGet(token, "/answer/status/screens/common"); }
    catch (e) { return { error: "status " + String(e).slice(0, 60) }; }
    const allSecs = status.screens.flatMap((s) => s.sections.filter((x) => !x.isIgnored));
    const greenBefore = allSecs.filter((s) => s.isComplete).length;
    const incomplete = allSecs.filter((s) => !s.isComplete);

    // One fill pass over a section: post every required/visible/incomplete question we
    // can resolve. Returns {posted, skipped, name}. Answering one field can REVEAL another
    // (conditional cascades — e.g. "I can access my transcript" unlocks an acknowledgment),
    // so the caller re-runs a section until a pass posts nothing new.
    async function fillSectionPass(sectionId) {
      const schema = (await caGet(token, "/datacatalog/sections/" + sectionId + "/questions")).questions || [];
      const ans = await caGet(token, "/answer/sections/" + sectionId);
      const secName = caClean(schema[0] && schema[0].name);
      const ansByQ = {}; for (const a of ans) ansByQ[a.questionId] = a;
      const occ = {}; const batch = []; const skipped = [];
      const ordered = schema.slice().sort((a, b) => (a.orderSeq || 0) - (b.orderSeq || 0));
      for (const q of ordered) {
        const field = caMatchField(idx, secName, q.label);
        if (field && field.concept && field.concept.includes(".")) occ[field.concept] = (occ[field.concept] || 0) + 1;
        const a = ansByQ[q.questionId];
        if (!a || !a.isRequired || !a.isVisible || a.isComplete) continue;
        const rowN = field && field.concept && field.concept.includes(".") ? occ[field.concept] : 1;
        let resp = null;
        try { resp = field ? caResolve(q, field, answers, geo, rowN) : null; } catch (e) { resp = null; }
        // Unmapped mandatory acknowledgment checkbox — the only valid value is checked = "1".
        if (resp == null && !field && (q.questionType === 7 || q.questionType === 8)) resp = "1";
        if (resp == null || resp === "") { skipped.push(caClean(q.label).slice(0, 30)); continue; }
        batch.push({ questionId: q.questionId, response: resp, memberQuestionTemplateId: q.memberQuestionTemplateId || null });
      }
      if (batch.length) { try { await caPost(token, batch); } catch (e) { /* best effort */ } }
      return { posted: batch.length, skipped, name: secName };
    }

    const report = [];
    for (const sec of incomplete) {
      let name = "", totalPosted = 0, skipped = [];
      try {
        for (let pass = 0; pass < 3; pass++) {
          const r = await fillSectionPass(sec.sectionId);
          name = r.name; skipped = r.skipped;
          totalPosted += r.posted;
          if (!r.posted) break; // nothing new posted -> no further reveals
        }
        report.push({ sectionId: sec.sectionId, name, posted: totalPosted, skipped });
      } catch (e) { report.push({ sectionId: sec.sectionId, error: String(e).slice(0, 50) }); }
    }

    let after;
    try { after = await caGet(token, "/answer/status/screens/common"); }
    catch (e) { after = status; }
    const afterSecs = after.screens.flatMap((s) => s.sections.filter((x) => !x.isIgnored));
    const greenAfter = afterSecs.filter((s) => s.isComplete).length;
    const stillIncomplete = afterSecs.filter((s) => !s.isComplete).map((s) => s.sectionId);
    return { greenBefore, greenAfter, total: afterSecs.length, stillIncomplete, report };
  }

  // ── message router (MV3: sendResponse + return true for async) ───────────────
  function route(msg) {
    if (!msg || !msg.type) return undefined;
    switch (msg.type) {
      case "QC_PING": return Promise.resolve({ ok: true, commonApp: isCommonApp() });
      case "QC_CAPTURE": return Promise.resolve({ fields: captureFields(), title: sectionTitle(), addButtons: captureAddButtons() });
      case "QC_APPLY": return applyDecisions(msg.decisions, msg.documents, msg.fields).catch((e) => ({ filled: 0, uploaded: 0, error: String(e) }));
      case "QC_FILL_MAP": return fillFromMap(msg.map, msg.answers, msg.documents).catch((e) => ({ filled: 0, matched: 0, error: String(e) }));
      case "QC_ADD_ROWS": return addRows(msg.clicks || []).catch((e) => ({ added: 0, error: String(e) }));
      case "QC_DEEP_SCAN": return deepScanScreen().catch((e) => ({ section: "", fields: [], error: String(e) }));
      case "QC_FILL": return deterministicFill(msg.steps || [], msg.documents || []).catch((e) => ({ filled: 0, uploaded: 0, error: String(e) }));
      case "QC_CONTINUE_INFO": { const c = findContinue(); return Promise.resolve({ hasContinue: !!c }); }
      case "QC_CLICK_CONTINUE": return clickContinue();
      case "QC_HIGHLIGHT": { highlight(findContinue(), msg.text); return Promise.resolve({ ok: true }); }
      case "QC_SECTIONS": return Promise.resolve({ sections: Object.keys(sectionLinks()), commonApp: isCommonApp() });
      case "QC_GOTO_SECTION": return gotoSection(msg.name);
      case "QC_API_FILL": return apiFill(msg.map, msg.answers).catch((e) => ({ error: String(e) }));
      default: return undefined;
    }
  }
  // Page-injection entry point: lets the same fill logic be driven when injected into
  // the page's main world (no chrome.runtime there). Harmless in the content-script world.
  try { globalThis.__QC = { fillFromMap, captureFields, deepScanScreen, sectionTitle, fillRepeats, apiFill }; } catch (e) { /* noop */ }
  try {
    browser.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      const p = route(msg);
      if (p === undefined) return false;
      Promise.resolve(p).then(sendResponse).catch((e) => sendResponse({ error: String(e) }));
      return true;
    });
  } catch (e) { /* no chrome.runtime — running page-injected */ }
})();
