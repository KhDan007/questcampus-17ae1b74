const browser = globalThis.browser ?? chrome; // Chrome MV3 shim
const $ = (id) => document.getElementById(id);
const WEB = "https://questcampus.space";
const bg = (msg) => browser.runtime.sendMessage(msg);
const norm = (s) => (s || "").toLowerCase().replace(/\s+/g, " ").replace(/[*:_]/g, " ").replace(/\s+/g, " ").trim();
let bundle = null;
let caMap = null; // the authoritative Common App map (from Cowork), fetched once on connect

function show(view) {
  for (const v of ["loading", "login", "connected"]) $("view-" + v).classList.toggle("hidden", v !== view);
}
function escapeHtml(s) {
  return String(s).replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
}
function flashLoginError(text) { const el = $("login-error"); el.textContent = text; el.classList.remove("hidden"); }

// ── init / auth ───────────────────────────────────────────────────────────────
async function init() {
  show("loading");
  $("link-signup").href = WEB;
  const state = await bg({ type: "STATE" });
  if (state && state.token) await loadConnected();
  else show("login");
}

async function loadConnected() {
  show("loading");
  let res = await bg({ type: "BUNDLE" });
  if (!res || !res.ok) {
    const err = (res && res.error) || "Couldn't load your profile.";
    const invalid = /expired|not signed in|invalid/i.test(err);
    // Transient data-load error (500/network) → retry ONCE; never log the user out.
    if (!invalid) {
      await new Promise((r) => setTimeout(r, 1200));
      res = await bg({ type: "BUNDLE" });
    }
    if (!res || !res.ok) {
      // Only clear the session when it's genuinely invalid (expired/not-signed-in).
      if (invalid) await bg({ type: "SIGNOUT" });
      show("login");
      flashLoginError(invalid ? err : `${err} Your login is still valid — reopen the panel to retry.`);
      return;
    }
  }
  bundle = res.data;
  // Fetch the bundled Common App map once (Cowork's authoritative field map).
  const m = await bg({ type: "GET_MAP" });
  caMap = m && m.ok ? m.map : null;
  renderConnected();
  show("connected");
  const tab = await activeTab();
  if (tab) refreshSections(tab.id);
}

function renderConnected() {
  $("account-email").textContent = bundle.userEmail || "";
  const c = bundle.completeness || { percent: 0 };
  const pct = Math.max(0, Math.min(100, Math.round(c.percent || 0)));
  $("progress-label").textContent = c.complete ? "Profile complete" : `Profile ${pct}% complete`;
  $("progress-count").textContent = `${c.requiredDone || 0}/${c.requiredTotal || 0} fields`;
  const bar = $("bar-fill");
  bar.style.width = pct + "%";
  bar.classList.toggle("done", !!c.complete);
  $("link-profile").href = WEB + "/common-app";

  const docs = bundle.documents || [];
  const docsEl = $("docs");
  if (docs.length) {
    docsEl.classList.remove("hidden");
    const wrap = $("docs-chips");
    wrap.innerHTML = "";
    for (const d of docs) {
      const s = document.createElement("span");
      s.className = "chip-doc";
      s.textContent = d.docType.replace(/_/g, " ");
      wrap.appendChild(s);
    }
  } else docsEl.classList.add("hidden");
}

$("btn-google").onclick = async () => {
  const btn = $("btn-google");
  $("login-error").classList.add("hidden");
  const original = btn.innerHTML;
  btn.disabled = true;
  btn.innerHTML = `<span class="spinner spinner-sm"></span> Connecting…`;
  const res = await bg({ type: "GOOGLE" });
  btn.disabled = false;
  btn.innerHTML = original;
  if (!res || !res.ok) return flashLoginError((res && res.error) || "Google sign-in failed.");
  await loadConnected();
};

$("btn-connect").onclick = async () => {
  const email = $("email").value.trim();
  const password = $("password").value;
  $("login-error").classList.add("hidden");
  if (!email || !password) return flashLoginError("Enter your email and password.");
  const btn = $("btn-connect");
  btn.disabled = true;
  btn.textContent = "Connecting…";
  const res = await bg({ type: "SIGNIN", email, password });
  btn.disabled = false;
  btn.textContent = "Connect";
  if (!res || !res.ok) return flashLoginError((res && res.error) || "Couldn't sign in.");
  await loadConnected();
};

$("btn-signout").onclick = async () => {
  await bg({ type: "SIGNOUT" });
  bundle = null;
  $("email").value = "";
  $("password").value = "";
  show("login");
};

// ── tab helpers ───────────────────────────────────────────────────────────────
async function activeTab() {
  const t = await browser.tabs.query({ active: true, currentWindow: true });
  return t[0] || null;
}
async function toTab(tabId, msg) {
  try { return await browser.tabs.sendMessage(tabId, msg); }
  catch (e) { return null; } // no content script on this page
}
function hostOf(tab) {
  try { return new URL(tab.url).host; } catch (e) { return ""; }
}

// ── live log ──────────────────────────────────────────────────────────────────
function clearLog() { const l = $("log"); l.innerHTML = ""; l.classList.remove("hidden"); }
function log(text, kind) {
  const l = $("log");
  l.classList.remove("hidden");
  const row = document.createElement("div");
  row.className = "log-line" + (kind ? " " + kind : "");
  const ic = kind === "ok" ? "✓" : kind === "warn" ? "!" : kind === "err" ? "×" : "•";
  row.innerHTML = `<span class="ic">${ic}</span><span>${escapeHtml(text)}</span>`;
  l.appendChild(row);
  l.scrollTop = l.scrollHeight;
}
function setBusy(b) { $("btn-auto").disabled = b; $("btn-fill").disabled = b; }

// ── sections ──────────────────────────────────────────────────────────────────
async function refreshSections(tabId) {
  const r = await toTab(tabId, { type: "QC_SECTIONS" });
  const el = $("sections");
  const wrap = $("sections-chips");
  const list = (r && r.sections) || [];
  if (!r || !r.commonApp || !list.length) { el.classList.add("hidden"); return; }
  const ALL = ["Profile", "Family", "Education", "Testing", "Activities", "Writing"];
  wrap.innerHTML = "";
  for (const name of ALL) {
    const present = list.includes(name);
    const b = document.createElement("button");
    b.className = "sec-chip" + (present ? "" : " off");
    b.textContent = name;
    if (present) b.onclick = () => goSection(name);
    wrap.appendChild(b);
  }
  el.classList.remove("hidden");
}

async function goSection(name) {
  const tab = await activeTab();
  if (!tab) return;
  clearLog();
  log(`Opening ${name}…`);
  await toTab(tab.id, { type: "QC_GOTO_SECTION", name });
  await refreshSections(tab.id);
  await autoFill(); // walk the section we just opened
}

// ── fill one screen from the AUTHORITATIVE MAP ──────────────────────────────────
// The map (from Cowork) already knows, per section, which concept every labelled
// field holds — so the extension just matches the map's section to this screen and
// fills each field's value from the answer store. Two passes catch conditional
// reveals (answering one field surfaces another). No LLM, no guessing.
async function fillScreen(tabId) {
  if (!caMap) return { noMap: true };
  const answers = bundle.answers || {};
  let grandFilled = 0, matched = 0, saw = false;
  for (let pass = 0; pass < 2; pass++) {
    const r = await toTab(tabId, { type: "QC_FILL_MAP", map: caMap, answers, documents: bundle.documents });
    if (!r) return pass === 0 ? { noContent: true } : { filled: grandFilled, matched };
    saw = true;
    grandFilled += r.filled || 0;
    matched = Math.max(matched, r.matched || 0);
    if (!(r.filled > 0)) break; // no progress this pass → nothing more to reveal
  }
  if (matched === 0) return { empty: true, filled: 0 };
  return { filled: grandFilled, matched, uploaded: 0, saw };
}

$("btn-fill").onclick = async () => {
  const tab = await activeTab();
  if (!tab) return;
  setBusy(true);
  clearLog();
  log("Reading this screen…");
  const r = await fillScreen(tab.id);
  if (r.noMap) log("Field map not loaded — reinstall the extension.", "err");
  else if (r.noContent) log("This page can't be filled — open a Common App form.", "warn");
  else if (r.empty) log("Nothing here the map recognises — open a form section.", "warn");
  else log(`${r.filled || 0} filled of ${r.matched || 0} known. Review before submitting.`, r.filled ? "ok" : "warn");
  setBusy(false);
};

// ── auto-fill: fill, click Continue, advance, repeat ────────────────────────────
$("btn-auto").onclick = () => autoFill();

async function autoFill() {
  const tab = await activeTab();
  if (!tab) return;
  setBusy(true);
  clearLog();
  log("Auto-filling from your QuestCampus profile — walking every screen…");
  let total = 0, screens = 0, dry = 0;
  for (let i = 0; i < 25; i++) {
    const r = await fillScreen(tab.id);
    if (r.noMap) { log("Field map not loaded — reinstall the extension.", "err"); break; }
    if (r.noContent) { log("This page can't be filled — open a Common App form.", "warn"); break; }
    if (r.empty && screens === 0) { log("Nothing here the map recognises — open a form section, or use the chips below.", "warn"); await refreshSections(tab.id); break; }
    screens++;
    total += r.filled || 0;
    dry = r.filled ? 0 : dry + 1;
    log(`Screen ${screens}: ${r.filled || 0} filled`, r.filled ? "ok" : "");

    const info = await toTab(tab.id, { type: "QC_CONTINUE_INFO" });
    if (!info || !info.hasContinue) {
      log(`Done — ${total} field(s) across ${screens} screen(s). Pick the next section below.`, "ok");
      await refreshSections(tab.id);
      break;
    }
    if (dry >= 2) {
      log("A field here needs your input. Complete the highlighted field, then click Continue.", "warn");
      await toTab(tab.id, { type: "QC_HIGHLIGHT", text: "Complete the flagged field, then click" });
      break;
    }
    const cc = await toTab(tab.id, { type: "QC_CLICK_CONTINUE" });
    await refreshSections(tab.id);
    if (!cc || !cc.moved) {
      log(`Filled ${total} so far. A required field likely needs you — complete it, then Auto-fill again.`, "warn");
      await toTab(tab.id, { type: "QC_HIGHLIGHT", text: "A field here needs you — then Continue" });
      break;
    }
  }
  // Deterministic closer: some Common App widgets (the EDQ address autocomplete, the
  // parent college lookup, the late-hydrating activity choices) resist DOM automation.
  // Write the remaining required answers straight through Common App's answer API and
  // report the TRUE completion from Common App's own status feed — not a DOM guess.
  if (caMap && bundle) {
    log("Finishing the last fields directly through Common App…");
    const fin = await toTab(tab.id, { type: "QC_API_FILL", map: caMap, answers: bundle.answers || {} });
    if (fin && fin.greenAfter != null) {
      const left = (fin.stillIncomplete || []).length;
      log(`${fin.greenAfter}/${fin.total} sections complete${left ? ` — ${left} still need you` : " — every section is green ✓"}`, left ? "warn" : "ok");
      await refreshSections(tab.id);
    } else if (fin && fin.notCommonApp) { /* not on Common App — silent */ }
    else if (fin && fin.noAuth) { log("Sign in to Common App in this tab to finish the last fields.", "warn"); }
  }
  setBusy(false);
}

// Keep the section chips fresh as the user navigates the SPA.
browser.tabs.onActivated.addListener(async () => { if (bundle) { const t = await activeTab(); if (t) refreshSections(t.id); } });
browser.tabs.onUpdated.addListener(async (_id, info, tab) => {
  if (bundle && tab && tab.active && info.status === "complete") refreshSections(tab.id);
});

init();
